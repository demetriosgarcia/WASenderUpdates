(function(){
  function applyWF(WF){
    if (!WF) return false;

    // mais candidatos: cobre variações de build
    const f =
      WF.createWid ||
      WF.createWidFromWid ||
      WF.createWidFromString ||
      WF.toWid ||
      WF.fromString ||
      WF.fromWid ||
      WF.toUserWid ||
      WF.toUserWidOrThrow ||
      null;

    if (!f || typeof f !== 'function') return false;

    // normalize sem sobrescrever o que já existe
    if (typeof WF.toWid               !== 'function') WF.toWid = f;
    if (typeof WF.toUserWid           !== 'function') WF.toUserWid = f;
    if (typeof WF.toUserWidOrThrow    !== 'function') WF.toUserWidOrThrow = f;
    if (typeof WF.createWid           !== 'function') WF.createWid = f;
    if (typeof WF.createWidFromWid    !== 'function') WF.createWidFromWid = f;
    if (typeof WF.createWidFromString !== 'function') WF.createWidFromString = f;
    if (typeof WF.fromString          !== 'function') WF.fromString = f;
    if (typeof WF.fromWid             !== 'function') WF.fromWid = f;

    return true;
  }

  function findWF(){
    const w = (window.WPP && WPP.whatsapp) || {};
    // cobre default, nome normal, e um fallback global raro
    return w?.WidFactory?.default || w?.WidFactory || w?.widFactory || window.WidFactory || null;
  }

  function run(){ return applyWF(findWF()); }

  // tenta agora; senão, ganchos + polling leve
  if (!run()) {
    try { if (WPP?.webpack?.onReady) WPP.webpack.onReady(()=>{ try{ run(); }catch{} }); } catch {}
    try { if (typeof WPP?.on === 'function') WPP.on('conn.main_ready', ()=>{ try{ run(); }catch{} }); } catch {}
    // polling curtinho (3s)
    let tries = 30;
    const t = setInterval(()=>{ if (run() || --tries<=0) clearInterval(t); }, 100);
  }
})();


// helpers-wa.js (clean)
(function () {
  if (window.__wpp_helpers_v1) return;
  window.__wpp_helpers_v1 = true;

  // =================== utils ===================
  function toSer(x){
    if (!x) return '';
    if (x._serialized) return x._serialized;
    if (x.id && x.id._serialized) return x.id._serialized;
    if (x.wid && x.wid._serialized) return x.wid._serialized;
    if (x.user && x.user._serialized) return x.user._serialized;
    if (typeof x === 'string') return x;
    return String(x||'');
  }
  function norm(j){
    if (!j) return '';
    j = String(toSer(j)||'').toLowerCase();
    j = j.replace('@s.whatsapp.net','@c.us').replace('@whatsapp.net','@c.us');
    const at = j.indexOf('@'), colon = j.indexOf(':');
    if (colon > -1 && (at === -1 || colon < at)) j = j.slice(0, colon) + (at > -1 ? j.slice(at) : '');
    return j;
  }
  function arrFromModels(m){
    try{ if (m && typeof m.getModelsArray === 'function') return m.getModelsArray()||[]; }catch(e){}
    try{ if (m && m.models && m.models.length){ const a=[]; for (let i=0;i<m.models.length;i++) a.push(m.models[i]); return a; } }catch(e){}
    try{ if (m && m._models && m._models.length){ const b=[]; for (let j=0;j<m._models.length;j++) b.push(m._models[j]); return b; } }catch(e){}
    return [];
  }
  function getChatsAny(){
    const ww = (window.WPP && WPP.whatsapp) ? WPP.whatsapp : null;
    try{ if (window.WPP && WPP.chat && typeof WPP.chat.list === 'function') return {mode:'WPP.chat.list', chatsPromise: WPP.chat.list()}; }catch(e){}
    let arr = [];
    try{ const a=arrFromModels(ww && ww.ChatStore);    if (a.length) arr=arr.concat(a); }catch(e){}
    try{ const b=arrFromModels(ww && ww.ContactStore); if (b.length) arr=arr.concat(b); }catch(e){}
    const seen={}, out=[];
    for (let i=0;i<arr.length;i++){
      const c=arr[i], id=norm(c && (c.id||c));
      if (!id) continue;
      if (!seen[id]){ seen[id]=1; out.push(c); }
    }
    return {mode:'Store(Chat+Contact)', chats: out};
  }
  function getContactsAny(){
    const ww = (window.WPP && WPP.whatsapp) ? WPP.whatsapp : null;
    try{ if (window.WPP && WPP.contact && typeof WPP.contact.list === 'function') return {mode:'WPP.contact.list', contactsPromise: WPP.contact.list()}; }catch(e){}
    const arr = arrFromModels(ww && ww.ContactStore);
    return {mode:'Store.ContactStore', contacts: arr||[]};
  }
  function getChatLabelsArray(c){
    try{ if (c && c.labels && Array.isArray(c.labels.models)) return c.labels.models; }catch(e){}
    try{ if (c && Array.isArray(c.labels)) return c.labels; }catch(e){}
    try{ if (c && c.__x_labels && c.__x_labels.models) return c.__x_labels.models; }catch(e){}
    try{
      if (c && c.labelsIndex && typeof c.labelsIndex === 'object'){
        const arr=[], li=c.labelsIndex;
        for (const lid in li){ if (li.hasOwnProperty(lid) && li[lid]) arr.push({id:lid}); }
        return arr;
      }
    }catch(e){}
    return [];
  }
  function buildLabelMap(cb){
    const map = {};
    try{
      if (window.WPP && WPP.labels && typeof WPP.labels.getAllLabels === 'function'){
        const p = WPP.labels.getAllLabels();
        if (p && typeof p.then === 'function'){
          p.then(function(all){
            if (Array.isArray(all)){
              for (let i=0;i<all.length;i++){
                const l=all[i];
                const id = String((l && (l.id||l.lid||l.labelId||l._serialized)) || l || '').trim();
                const nm = String((l && (l.name||l.title||l.label)) || '').trim();
                if (id) map[id]=nm;
              }
            }
            finish();
          }).catch(function(){ finish(); });
          return;
        }
      }
    }catch(e){}
    finish();
    function finish(){
      try{
        const ww = (window.WPP && WPP.whatsapp) ? WPP.whatsapp : null;
        const LS = ww && ww.LabelStore;
        const arr = arrFromModels(LS);
        for (let k=0;k<arr.length;k++){
          const l2=arr[k];
          const id2 = String((l2 && (l2.id||l2.lid||l2.labelId||l2._serialized)) || l2 || '').trim();
          const nm2 = String((l2 && (l2.name||l2.title||l2.label)) || '').trim();
          if (id2 && !map[id2]) map[id2]=nm2;
        }
      }catch(e){}
      try{ cb(map); }catch(e){}
    }
  }
  function getMyId(){
    const cands = [];
    try{ cands.push(toSer(WPP && WPP.conn && WPP.conn.wid)); }catch(e){}
    try{ cands.push(toSer(WPP && WPP.conn && WPP.conn.user && WPP.conn.user.id)); }catch(e){}
    try{ cands.push(toSer(WPP && WPP.whatsapp && WPP.whatsapp.Conn && WPP.whatsapp.Conn.wid)); }catch(e){}
    for (let i=0;i<cands.length;i++){ const s=norm(cands[i]); if (s) return s; }
    return '';
  }

  // mime / jid helpers
  const __mimeFromExt = (fn='') => {
    const e = (fn || '').toLowerCase().split('.').pop() || '';
    const map = {
      jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', webp:'image/webp', gif:'image/gif',
      mp4:'video/mp4', mov:'video/quicktime', m4v:'video/x-m4v', webm:'video/webm',
      mp3:'audio/mpeg', m4a:'audio/mp4',
      ogg:'audio/ogg; codecs=opus',
      oga:'audio/ogg; codecs=opus',
      opus:'audio/ogg; codecs=opus',
      weba:'audio/webm', wav:'audio/wav',
      pdf:'application/pdf',
      doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      xls:'application/vnd.ms-excel', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      txt:'text/plain'
    };
    return map[e] || 'application/octet-stream';
  };
  
  const __ensureJid = (s) => {
    if (!s) return '';
    s = String(s).trim().toLowerCase();
    if (s.endsWith('@g.us') || s.endsWith('@c.us')) return s;
    if (/^\d+$/.test(s)) return s + '@c.us';
    return s;
  };

  // ======= NOVO: __ensureDataUrl robusto (suporta Blob/ArrayBuffer/TypedArray) =======
  async function __ensureDataUrl(src, fallbackMime) {
    if (!src) return null;
    const mime = fallbackMime || 'application/octet-stream';

    // string
    if (typeof src === 'string') {
      if (/^data:/i.test(src))   return src;          // já é data URL
      if (/^https?:\/\//i.test(src)) return src;      // deixe o WA baixar direto
      if (/^blob:/i.test(src)) {                       // converte blob: -> data:
        const res = await fetch(src);
        const blob = await res.blob();
        const buf  = await blob.arrayBuffer();
        const b64  = btoa(String.fromCharCode(...new Uint8Array(buf)));
        return `data:${blob.type || mime};base64,${b64}`;
      }
      // base64 cru sem prefixo
      return `data:${mime};base64,${src}`;
    }

    // Blob
    if (typeof Blob !== 'undefined' && src instanceof Blob) {
      const buf = await src.arrayBuffer();
      const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
      return `data:${src.type || mime};base64,${b64}`;
    }

    // ArrayBuffer / TypedArray
    if (src instanceof ArrayBuffer || (typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView && ArrayBuffer.isView(src))) {
      const view = src instanceof ArrayBuffer ? new Uint8Array(src) : new Uint8Array(src.buffer, src.byteOffset, src.byteLength);
      const b64  = btoa(String.fromCharCode(...view));
      return `data:${mime};base64,${b64}`;
    }

    // fallback genérico
    return String(src);
  }

  // =================== labels / lists ===================
  window.__wppChatsByLabel = function(labelName, showConsole){
    const wanted = String(labelName||'').trim().toLowerCase();
    window.__wpp_chats_by_labels = '[]';
    buildLabelMap(function(id2name){
      const got = getChatsAny();
      function process(chats){
        const out=[];
        for (let i=0;i<(chats||[]).length;i++){
          const c=chats[i];
          const id=norm(c && (c.id||c)); if (!id) continue;
          const suf=id.slice(-5); if (suf!=='@c.us' && suf!=='@g.us') continue;
          const labs=getChatLabelsArray(c);
          let match=false; const labelsOut=[];
          for (let k=0;k<labs.length;k++){
            const l=labs[k];
            const lid=String((l && (l.id||l.lid||l.labelId)) || l || '').trim();
            const nm=String((l && (l.name||l.title)) || (id2name[lid]||'')).trim();
            if (nm) labelsOut.push(nm);
            if (!match && nm && nm.toLowerCase()===wanted) match=true;
          }
          if (!match) continue;
          let groupName='', name='';
          try{ groupName=(c.groupMetadata&&c.groupMetadata.subject) || (c.__x_groupMetadata&&c.__x_groupMetadata.subject) || c.name || ''; }catch(e){}
          try{ name=c.formattedName || (c.contact&&c.contact.name) || groupName || ''; }catch(e){}
          out.push({ id:id, name:name, labels: labelsOut.join(', ') });
        }
        if (showConsole){ try{ console.table(out.slice(0,100)); }catch(e){ console.log(out); } console.log('Total:', out.length); }
        window.__wpp_chats_by_labels = JSON.stringify(out);
      }
      if (got.chatsPromise && typeof got.chatsPromise.then==='function'){
        got.chatsPromise.then(process).catch(function(e){ window.__wpp_chats_by_labels = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
      }else{
        process(got.chats||[]);
      }
    });
  };

  window.__wppGetGroupParticipants = function(gid, showConsole){
    window.__wpp_gp = '[]';
    const J = (p) => ({
      id: toSer(p && (p.id||p.wid||p.user)),
      name: (p && p.contact && (p.contact.name||p.contact.pushname)) || p.displayName || p.name || '',
      isAdmin: !!(p && (p.isAdmin || String(p.admin).toLowerCase()==='admin' || String(p.admin).toLowerCase()==='superadmin')),
      isSuperAdmin: !!(p && (p.isSuperAdmin || String(p.admin).toLowerCase()==='superadmin'))
    });
    try{
      if (window.WPP && WPP.group && typeof WPP.group.getParticipants === 'function'){
        WPP.group.getParticipants(gid).then(function(arr){
          arr = arr || [];
          const rows = [];
          for (let i=0;i<arr.length;i++) rows.push(J(arr[i]));
          if (showConsole){ try{ console.table(rows.slice(0,100)); }catch(e){ console.log(rows); } console.log('Total:', rows.length); }
          window.__wpp_gp = JSON.stringify(rows);
        }).catch(function(e){
          window.__wpp_gp = JSON.stringify({ __err: String(e&&e.message||e) });
          if (showConsole) console.error(e);
        });
        return;
      }
    }catch(e){}

    try{
      const ww = (WPP && WPP.whatsapp) || {};
      const GS = ww.GroupMetadataStore, CS = ww.ChatStore;
      let meta = null;
      try{ meta = GS && GS.find && GS.find(gid); }catch(e){}
      if (!meta){
        try{
          const chat = CS && (CS.get && CS.get(gid));
          meta = chat && (chat.groupMetadata || chat.__x_groupMetadata);
        }catch(e){}
      }
      const parts = (meta && meta.participants) || [];
      const rows2 = [];
      for (let j=0;j<parts.length;j++) rows2.push(J(parts[j]));
      if (showConsole){ try{ console.table(rows2.slice(0,100)); }catch(e){ console.log(rows2); } console.log('Total:', rows2.length); }
      window.__wpp_gp = JSON.stringify(rows2);
    }catch(e){
      window.__wpp_gp = JSON.stringify({ __err: String(e&&e.message||e) });
      if (showConsole) console.error(e);
    }
  };


  window.__wppGetGroupParticipantsNova = function (gid, showConsole) {
    window.__wpp_gp = '[]';
  
    // helper para serializar
    const toSer = (x) =>
      (x && (x._serialized || x.id?._serialized || x.wid?._serialized || x.user || x)) || '';
  
    // pega o número do objeto de contato/participante por vários caminhos
    const extractPhone = (p) => {
      try {
        const c = p?.contact || p; // às vezes o próprio p tem os campos
        const candSerialized =
          c?.phoneNumber?._serialized ||
          c?.__x_phoneNumber?._serialized ||
          c?.pnForLid?._serialized ||            // alguns builds expõem pnForLid
          c?.formattedPhone ||                   // pode vir formatado (com símbolos)
          c?.id?._serialized || c?.id || '';
  
        // normaliza → só dígitos se for string “formatada”
        let s = String(candSerialized || '');
        if (!/@(c|g)\.us$/i.test(s)) {
          const digits = s.replace(/\D+/g, '');
          if (digits.length >= 6) return digits; // número plausível
        }
        if (/@c\.us$/i.test(s)) return s.split('@')[0];
  
        // mais tentativas (alguns modelos expõem displayNameOrPnForLid etc.)
        const alt =
          c?.displayNameOrPnForLid ||
          c?.formattedUser ||
          c?.formattedName ||
          '';
        const digitsAlt = String(alt).replace(/\D+/g, '');
        if (digitsAlt.length >= 6) return digitsAlt;
  
      } catch {}
      return '';
    };
  
    // monta cada linha; tenta resolver LID => c.us via queryExists, mas já usa phone do contato
    const J = (p) => {
      let wid = String(toSer(p && (p.id || p.wid || p.user)) || '').toLowerCase();
  
      // 1) tenta tirar número do próprio contato (mesmo se for LID)
      let phone = extractPhone(p);
  
      // 2) se o id já for @c.us, ele também dá o número “oficial”
      if (/@c\.us$/.test(wid)) phone = wid.split('@')[0];
  
      // 3) best effort: tentar resolver LID -> JID clássico
      if (!phone && !/@c\.us$/.test(wid)) {
        try {
          const q =
            WPP && WPP.contact && typeof WPP.contact.queryExists === 'function'
              ? WPP.contact.queryExists(wid)
              : null;
          if (q && typeof q.then === 'function') {
            q.then((r) => {
              const rwid = String(
                toSer(r?.wid || r?.jid || r?.id || '') || ''
              ).toLowerCase();
              if (/@c\.us$/.test(rwid)) {
                try {
                  const arr = JSON.parse(window.__wpp_gp || '[]');
                  const row = arr.find((x) => x.id === wid || x.id === rwid);
                  if (row) {
                    row.id = rwid;
                    row.phone = rwid.split('@')[0];
                    window.__wpp_gp = JSON.stringify(arr);
                    if (showConsole) console.log('[resolveu LID]', rwid, row.phone);
                  }
                } catch {}
              }
            }).catch(() => {});
          }
        } catch {}
      }
  
      return {
        id: wid,
        name:
          (p?.contact && (p.contact.name || p.contact.pushname)) ||
          p?.displayName ||
          p?.name ||
          '',
        phone, // agora tenta vir do contact mesmo com @lid
        isAdmin:
          !!(
            p &&
            (p.isAdmin ||
              String(p.admin).toLowerCase() === 'admin' ||
              String(p.admin).toLowerCase() === 'superadmin')
          ),
        isSuperAdmin:
          !!(
            p &&
            (p.isSuperAdmin || String(p.admin).toLowerCase() === 'superadmin')
          ),
      };
    };
  
    const finish = (rows) => {
      try {
        window.__wpp_gp = JSON.stringify(rows || []);
        if (showConsole) {
          try { console.table((rows || []).slice(0, 100)); } catch { console.log(rows); }
          console.log('Total:', (rows || []).length);
        }
      } catch (e) {
        window.__wpp_gp = JSON.stringify({ __err: String(e && (e.message || e)) });
        if (showConsole) console.error(e);
      }
    };
  
    // 1) caminho WPP oficial
    try {
      if (WPP?.group?.getParticipants) {
        WPP.group.getParticipants(gid)
          .then((arr) => {
            arr = arr || [];
            const rows = [];
            for (let i = 0; i < arr.length; i++) rows.push(J(arr[i]));
            finish(rows); // qualquer resolução assíncrona depois ajusta window.__wpp_gp
          })
          .catch((e) => {
            window.__wpp_gp = JSON.stringify({ __err: String(e && (e.message || e)) });
            if (showConsole) console.error(e);
          });
        return;
      }
    } catch {}
  
    // 2) fallback por Stores
    try {
      const ww = (WPP && WPP.whatsapp) || {};
      const GS = ww.GroupMetadataStore, CS = ww.ChatStore;
      let meta = null;
      try { meta = GS?.find?.(gid); } catch {}
      if (!meta) {
        try {
          const chat = CS?.get?.(gid);
          meta = chat && (chat.groupMetadata || chat.__x_groupMetadata);
        } catch {}
      }
      const parts = (meta && meta.participants) || [];
      const rows2 = [];
      for (let j = 0; j < parts.length; j++) rows2.push(J(parts[j]));
      finish(rows2);
    } catch (e) {
      window.__wpp_gp = JSON.stringify({ __err: String(e && (e.message || e)) });
      if (showConsole) console.error(e);
    }
  };
  


  // Lista enxuta de grupos: [{ gid, name, participantsCount }]
  window.__wppGetGroupsShort = function (showConsole) {
    window.__wpp_groups_short = '[]';

    const toSer = x =>
      (x && (x._serialized || x.id?._serialized || x.wid?._serialized || x.user?._serialized)) ||
      (typeof x === 'string' ? x : '') || '';

    const norm = j => {
      if (!j) return '';
      j = String(toSer(j) || j).toLowerCase()
        .replace('@s.whatsapp.net','@c.us')
        .replace('@whatsapp.net','@c.us');
      const at = j.indexOf('@'), colon = j.indexOf(':');
      if (colon > -1 && (at === -1 || colon < at)) j = j.slice(0, colon) + (at > -1 ? j.slice(at) : '');
      return j;
    };

    (async () => {
      try {
        let chats = [];
        try { chats = await (WPP?.chat?.list?.() || Promise.resolve([])); } catch {}
        let groups = (chats || []).filter(c => norm(c?.id).endsWith('@g.us'));

        // fallback por Store
        if (!groups.length) {
          try {
            const w  = (WPP && WPP.whatsapp) || {};
            const CS = w.ChatStore;
            const arr = (CS?.getModelsArray?.() || CS?.models || CS?._models || []);
            groups = (arr || []).filter(c => norm(c?.id).endsWith('@g.us'));
          } catch {}
        }

        const rows = [];
        for (const g of (groups || [])) {
          const gid = norm(g?.id);
          if (!gid) continue;

          // nome com fallbacks
          let name = g?.contact?.name || g?.formattedTitle || g?.name || g?.__x_name || '';
          let meta = g?.groupMetadata || g?.__x_groupMetadata;
          if (!meta && WPP?.group?.getGroupMetadata) { try { meta = await WPP.group.getGroupMetadata(gid); } catch {} }
          if (!name) name = meta?.subject || '';
          if (!name) {
            try {
              const w = (WPP && WPP.whatsapp) || {};
              const chat = w.ChatStore?.get?.(gid) || w.ChatStore?.find?.(gid) || null;
              name = chat?.formattedTitle || chat?.contact?.name || chat?.name || chat?.__x_name || '';
            } catch {}
          }
          if (!name) name = gid;

          // contagem de participantes com fallbacks
          let participantsCount = 0;
          if (Array.isArray(meta?.participants)) {
            participantsCount = meta.participants.length|0;
          } else if (WPP?.group?.getParticipants) {
            try { const ps = await WPP.group.getParticipants(gid); participantsCount = (ps?.length||0)|0; } catch {}
          } else {
            try {
              const w = (WPP && WPP.whatsapp) || {};
              const meta2 = w.GroupMetadataStore?.find?.(gid) || w.ChatStore?.get?.(gid)?.groupMetadata || null;
              participantsCount = (meta2?.participants?.length || 0)|0;
            } catch {}
          }

          rows.push({ gid, name, participantsCount });
        }

        if (showConsole) { try { console.table(rows.slice(0,100)); } catch { console.log(rows); } }
        window.__wpp_groups_short = JSON.stringify(rows);
      } catch (e) {
        window.__wpp_groups_short = JSON.stringify({ __err: (e && e.message) || String(e) });
        if (showConsole) console.error(e);
      }
    })();
  };
  
  

  window.__wppGetGroupsWithRoles = function (showConsole) {
    window.__wpp_groups_roles = '[]';
  
    // ⬇️ myId robusto (usa __wppMyJid, depois getMyId, depois variáveis antigas)
    const myId =
      (typeof window.__wppMyJid === 'function' && window.__wppMyJid()) ||
      (typeof window.getMyId === 'function' && window.getMyId()) ||
      (window.__wpp_myid || window.__wppFixMyId?.() || '') || '';
  
    const toSer2 = (x) =>
      (x && (x._serialized || x.id?._serialized || x.wid?._serialized || x.user?._serialized)) ||
      (typeof x === 'string' ? x : '') || '';
  
    const norm2 = (j) => {
      if (!j) return '';
      j = String(toSer2(j) || j)
        .toLowerCase()
        .replace('@s.whatsapp.net', '@c.us')
        .replace('@whatsapp.net', '@c.us');
      const at = j.indexOf('@'), colon = j.indexOf(':');
      if (colon > -1 && (at === -1 || colon < at)) j = j.slice(0, colon) + (at > -1 ? j.slice(at) : '');
      return j;
    };
  
    const isAdminsOnly = (meta, g) => {
      try {
        if (
          meta?.announce || meta?.announcement || meta?.onlyAdmins ||
          meta?.announcementGroup || meta?.announcements ||
          meta?.isAnnounce || meta?.isAnnouncementGroup ||
          g?.announce || g?.announcement || g?.onlyAdmins
        ) return true;
  
        const v = (
          meta?.groupSendPermissions || meta?.sendMessagesPermissions ||
          meta?.sendPermission || g?.groupSendPermissions ||
          g?.sendMessagesPermissions || g?.sendPermission
        );
        if (typeof v === 'string' && v.toLowerCase().includes('admin')) return true;
        if (meta?.restrictMessages === true) return true;
        return false;
      } catch { return false; }
    };
  
    (async () => {
      try {
        const chats = await (WPP?.chat?.list?.() || Promise.resolve([]));
        const groups = (chats || []).filter((c) => norm2(c?.id).endsWith('@g.us'));
        const rows = [];
        const myNum = myId ? myId.split('@')[0] : '';
  
        for (const g of groups) {
          const gid  = norm2(g?.id);
          const name = g?.contact?.name || g?.formattedTitle || g?.name || '';
  
          let iAmParticipant = false, iAmAdmin = false;
          try { iAmParticipant = !!(await WPP?.group?.iAmMember?.(gid)); } catch {}
          try { iAmAdmin       = !!(await WPP?.group?.iAmAdmin?.(gid));  } catch {}
  
          // metadata (com fallbacks)
          let meta = g?.groupMetadata || g?.__x_groupMetadata;
          if (!meta && WPP?.group?.getGroupMetadata) { try { meta = await WPP.group.getGroupMetadata(gid); } catch {} }
          if (!meta) {
            try {
              const ww = (WPP && WPP.whatsapp) || {};
              const GS = ww.GroupMetadataStore, CS = ww.ChatStore;
              meta = GS?.find?.(gid) || CS?.get?.(gid)?.groupMetadata || CS?.get?.(gid)?.__x_groupMetadata || null;
            } catch {}
          }
  
          // participantes (com fallback)
          let participants = [];
          if (Array.isArray(meta?.participants)) participants = meta.participants;
          else if (WPP?.group?.getParticipants) { try { participants = await WPP.group.getParticipants(gid); } catch {} }
  
          // superadmin (criador/dono) + coerência com minha presença
          let iAmSuperAdmin = false;
          try {
            const owner = norm2(meta?.owner || meta?.creator);
            if (owner && myNum && owner.split('@')[0] === myNum) iAmSuperAdmin = true;
          } catch {}
  
          if (!iAmSuperAdmin && myNum && Array.isArray(participants)) {
            const me = participants.find((p) => {
              const pid = norm2((p && (p.id || p.wid || p.user)) || p);
              return pid && pid.split('@')[0] === myNum;
            });
            if (me) {
              const a = String(me.admin || '').toLowerCase();
              if (a === 'admin' || a === 'superadmin') iAmAdmin = true;
              if (a === 'superadmin' || me.isSuperAdmin) iAmSuperAdmin = true;
              iAmParticipant = true;
            }
          }
  
          const adminsOnly = isAdminsOnly(meta, g);
          const canSend = !!(iAmParticipant && (!adminsOnly || iAmAdmin || iAmSuperAdmin));
          const participantsCount = Array.isArray(participants) ? participants.length : (meta?.participants?.length || 0);
  
          rows.push({ gid, name, iAmParticipant, iAmAdmin, iAmSuperAdmin, participantsCount: participantsCount | 0, canSend });
        }
  
        if (showConsole) { try { console.table(rows.slice(0, 100)); } catch { console.log(rows); } console.log('Total grupos:', rows.length); }
        window.__wpp_groups_roles = JSON.stringify(rows);
      } catch (e) {
        window.__wpp_groups_roles = JSON.stringify({ __err: (e && e.message) || String(e) });
        if (showConsole) console.error(e);
      }
    })();
  };
  


  window.__wppGetContactsWithLabels = function(showConsole){
    window.__wpp_contacts = '[]';
    buildLabelMap(function(id2name){
      const gotChats = getChatsAny();
      function mapChats(chats){
        const labelsByJid = {};
        for (let i=0;i<(chats||[]).length;i++){
          const ch=chats[i], jid=norm(ch && (ch.id||ch));
          if (!jid) continue;
          const labs=getChatLabelsArray(ch);
          const names=[];
          for (let k=0;k<labs.length;k++){
            const l=labs[k];
            const lid=String((l && (l.id||l.lid||l.labelId)) || l || '').trim();
            const nm=String((l && (l.name||l.title)) || (id2name[lid]||'')).trim();
            if (nm) names.push(nm);
          }
          labelsByJid[jid] = names.join(', ');
        }
        const gotC = getContactsAny();
        function processContacts(contacts){
          const rows=[];
          for (let j=0;j<(contacts||[]).length;j++){
            const c=contacts[j];
            const id=norm(c && (c.id||c));
            if (!id || id.slice(-5)!=='@c.us') continue;
            let name=''; try{ name=(c.contact&&c.contact.name) || c.formattedName || c.pushname || c.name || ''; }catch(e){}
            rows.push({ id:id, name:name, labels: labelsByJid[id] || '' });
          }
          if (showConsole){ try{ console.table(rows.slice(0,100)); }catch(e){ console.log(rows); } console.log('Total contatos:', rows.length); }
          window.__wpp_contacts = JSON.stringify(rows);
        }
        if (gotC.contactsPromise && typeof gotC.contactsPromise.then==='function'){
          gotC.contactsPromise.then(processContacts).catch(function(e){ window.__wpp_contacts = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
        }else{
          processContacts(gotC.contacts||[]);
        }
      }
      if (gotChats.chatsPromise && typeof gotChats.chatsPromise.then==='function'){
        gotChats.chatsPromise.then(mapChats).catch(function(e){ window.__wpp_contacts = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
      }else{
        mapChats(gotChats.chats||[]);
      }
    });
  };

  window.__wppGetChatsWithLabels = function(showConsole){
    window.__wpp_chats = '[]';
    buildLabelMap(function(id2name){
      const got = getChatsAny();
      function process(chats){
        const rows=[];
        for (let i=0;i<(chats||[]).length;i++){
          const c=chats[i];
          const id=norm(c && (c.id||c));
          if (!id || id.slice(-5)!=='@c.us') continue;
          let name=''; try{ name=c.formattedName || (c.contact&&c.contact.name) || c.name || ''; }catch(e){}
          const labs=getChatLabelsArray(c), names=[];
          for (let k=0;k<labs.length;k++){
            const l=labs[k]; const lid=String((l&&(l.id||l.lid||l.labelId))||l||'').trim();
            const nm=String((l&&(l.name||l.title))||(id2name[lid]||'')).trim();
            if (nm) names.push(nm);
          }
          rows.push({ id:id, name:name, labels:names.join(', ') });
        }
        if (showConsole){ try{ console.table(rows.slice(0,100)); }catch(e){ console.log(rows); } console.log('Total chats (contatos):', rows.length); }
        window.__wpp_chats = JSON.stringify(rows);
      }
      if (got.chatsPromise && typeof got.chatsPromise.then==='function'){
        got.chatsPromise.then(process).catch(function(e){ window.__wpp_chats = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
      }else{
        process(got.chats||[]);
      }
    });
  };

  window.__wppGetContacts = function(showConsole){
    window.__wpp_contacts = '[]';
    const got = getContactsAny();
    function process(contacts){
      const rows=[];
      for (let i=0;i<(contacts||[]).length;i++){
        const c=contacts[i];
        const id=norm(c && (c.id||c));
        if (!id || id.slice(-5)!=='@c.us') continue;
        let name=''; try{ name=(c.contact&&c.contact.name) || c.formattedName || c.pushname || c.name || ''; }catch(e){}
        rows.push({ id:id, name:name });
      }
      if (showConsole){ try{ console.table(rows.slice(0,100)); }catch(e){ console.log(rows); } console.log('Total contatos:', rows.length); }
      window.__wpp_contacts = JSON.stringify(rows);
    }
    if (got.contactsPromise && typeof got.contactsPromise.then==='function'){
      got.contactsPromise.then(process).catch(function(e){ window.__wpp_contacts = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
    }else{
      process(got.contacts||[]);
    }
  };

  window.__wppGetAllLabelsWithCounts = function(showConsole){
    window.__wpp_labels = '[]';
    buildLabelMap(function(id2name){
      const order=[]; for (const lid in id2name){ if (id2name.hasOwnProperty(lid)) order.push(lid); }
      const counts={}; for (let i=0;i<order.length;i++) counts[order[i]]=0;

      const got = getChatsAny();
      function process(chats){
        for (let i=0;i<(chats||[]).length;i++){
          const c=chats[i], labs=getChatLabelsArray(c);
          for (let k=0;k<labs.length;k++){
            const l=labs[k]; const lid=String((l&&(l.id||l.lid||l.labelId))||l||'').trim();
            if (counts.hasOwnProperty(lid)) counts[lid] += 1;
          }
        }
        const rows=[];
        for (let j=0;j<order.length;j++){
          const id=order[j]; rows.push({ id:id, name:id2name[id]||'', count: counts[id]||0 });
        }
        if (showConsole){ try{ console.table(rows.slice(0,100)); }catch(e){ console.log(rows); } console.log('Total etiquetas:', rows.length); }
        window.__wpp_labels = JSON.stringify(rows);
      }
      if (got.chatsPromise && typeof got.chatsPromise.then==='function'){
        got.chatsPromise.then(process).catch(function(e){ window.__wpp_labels = JSON.stringify({__err:String(e&&e.message||e)}); if (showConsole) console.error(e); });
      }else{
        process(got.chats||[]);
      }
    });
  };

  // =================== group permission check ===================
  window.__wppCanISendToGroup = async function(gid, debug=false){
    const toStr = x => (x && (x._serialized || x.id?._serialized || x.wid?._serialized || x.user?._serialized)) || (typeof x==='string'?x:'') || '';
    const normG = j => {
      j = String(toStr(j)||'').trim().toLowerCase();
      if (!j.includes('@')) j += '@g.us';
      return j.replace('@c.us','@g.us').replace('@s.whatsapp.net','@g.us');
    };
    gid = normG(gid);

    try { await WPP.group.ensureGroupAndParticipants(gid); } catch {}
    const w = WPP?.whatsapp;
    const chat = w?.ChatStore?.get?.(gid) || w?.ChatStore?.find?.(gid) || null;

    let meta = chat?.groupMetadata || chat?.__x_groupMetadata || null;
    if (!meta && WPP?.group?.getGroupMetadata) { try { meta = await WPP.group.getGroupMetadata(gid); } catch {} }
    if (!meta) { try { meta = w?.GroupMetadataStore?.find?.(gid) || w?.GroupMetadataStore?.get?.(gid) || null; } catch {} }

    const adminsOnly = !!(
      meta?.announce || meta?.announcement || meta?.onlyAdmins || meta?.restrictMessages ||
      meta?.announcementGroup || meta?.announcements || meta?.isAnnounce || meta?.isAnnouncementGroup ||
      chat?.announce || chat?.announcement || chat?.onlyAdmins ||
      (typeof meta?.groupSendPermissions === 'string' && meta.groupSendPermissions.toLowerCase().includes('admin')) ||
      (typeof meta?.sendMessagesPermissions === 'string' && meta.sendMessagesPermissions.toLowerCase().includes('admin')) ||
      (typeof meta?.sendPermission === 'string' && meta.sendPermission.toLowerCase().includes('admin'))
    );

    let member=false, admin=false;
    try { member = !!(await WPP.group.iAmMember(gid)); } catch {}
    try { admin  = !!(await WPP.group.iAmAdmin(gid));  } catch {}

    let canWriteByChat = null;
    try {
      canWriteByChat = (typeof chat?.canSendMessage === 'function' ? !!chat.canSendMessage() : null);
      if (canWriteByChat === null && typeof chat?.canWrite === 'function') canWriteByChat = !!chat.canWrite();
      if (canWriteByChat === null && typeof chat?.isSendAllowed === 'function') canWriteByChat = !!chat.isSendAllowed();
      if (canWriteByChat === null && typeof chat?.isWritable === 'function') canWriteByChat = !!chat.isWritable();
      if (canWriteByChat === null && typeof chat?.hasWritePermission === 'function') canWriteByChat = !!chat.hasWritePermission();
      if (canWriteByChat === null && typeof chat?.composeSettings === 'function') canWriteByChat = !!chat.composeSettings()?.canSend;
      if (canWriteByChat === null && typeof chat?.getComposeSettings === 'function') canWriteByChat = !!chat.getComposeSettings()?.canSend;
      if (canWriteByChat === null && typeof chat?.isReadOnly !== 'undefined') canWriteByChat = !chat.isReadOnly;
      if (canWriteByChat === null && typeof chat?.__x_isReadOnly !== 'undefined') canWriteByChat = !chat.__x_isReadOnly;
      if (canWriteByChat === null && typeof chat?.__x_isGroupAnnounce !== 'undefined') canWriteByChat = !chat.__x_isGroupAnnounce;
    } catch {}

    const byPolicy = member && (!adminsOnly || admin);
    const canSend  = !!(byPolicy && (canWriteByChat !== false));

    if (debug) {
      const row = {
        gid,
        name: chat?.formattedTitle || chat?.contact?.name || chat?.name || '',
        adminsOnly, member, admin, canWriteByChat,
        isReadOnly: chat?.isReadOnly ?? chat?.__x_isReadOnly ?? null,
        isGroupAnnounce: chat?.__x_isGroupAnnounce ?? null,
        canSend
      };
      try { console.table([row]); } catch { console.log(row); }
    }
    return canSend;
  };

  // =================== open / check number ===================
  window.__wppOpen = async (jidOrNumber, debug = false) => {
    const jid = __ensureJid(jidOrNumber);
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const w   = WPP?.whatsapp || {};

    const F = (w.WidFactory || w.widFactory || w.WidFactory?.default) || {};
    const toWid =
      F.toWid || F.toUserWid || F.createWid || F.createWidFromWid || F.createWidFromString ||
      w.WidFactory?.createWid || w.widFactory?.createWid || null;
    const wid = toWid ? toWid(jid) : jid;

    const used = []; let okSoft = false;
    try { if (jid.endsWith('@g.us')) { await WPP.group.ensureGroupAndParticipants(jid); used.push('ensureGroupAndParticipants'); } } catch {}

    try { if (WPP?.chat?.openChatBottom)     { used.push('WPP.chat.openChatBottom');     await WPP.chat.openChatBottom(jid);     okSoft = true; } } catch {}
    try { if (WPP?.chat?.openChatFromUnread) { used.push('WPP.chat.openChatFromUnread'); await WPP.chat.openChatFromUnread(jid); okSoft = true; } } catch {}
    try { if (WPP?.chat?.openChat)           { used.push('WPP.chat.openChat');           await WPP.chat.openChat(jid);           okSoft = true; } } catch {}

    try { if (w.Cmd?.openChatAt)             { used.push('Cmd.openChatAt');             await w.Cmd.openChatAt(wid);            okSoft = true; } } catch {}
    try { if (w.Cmd?.openChat)               { used.push('Cmd.openChat');               await w.Cmd.openChat(wid);              okSoft = true; } } catch {}
    try { if (w.Router?.openChat)            { used.push('Router.openChat');            await w.Router.openChat(wid);           okSoft = true; } } catch {}

    await sleep(60);
    try {
      let chat = w.ChatStore?.get?.(wid) || w.ChatStore?.find?.(wid) || null;
      try { if (!chat && w.ChatStore?.getOrCreate) chat = w.ChatStore.getOrCreate(wid); } catch {}
      if (chat?.select) { chat.select(); used.push('chat.select()'); okSoft = true; }
    } catch {}

    await sleep(60);
    let active = null;
    try { active = w.ChatStore?.getActive?.() || w.ChatStore?.getActiveChat?.() || w.ChatStore?.active || null; } catch {}
    const toSer3 = (x) => (x?._serialized || x?.id?._serialized || x?.id || x?.user || String(x)||'').toLowerCase();
    let activeId = toSer3(active);                       // <= já existia
    const jidKey = String(jid).split('@')[0].toLowerCase();
    const eq = (a,b)=> String(a||'').toLowerCase().split('@')[0] === String(b||'').toLowerCase().split('@')[0];

    // >>> AQUI entra o mini-retry (opcional)
    for (let i = 0; i < 2; i++) {
      if (eq(activeId, jid)) {                           // se já bateu, retorna rápido
        if (debug) console.log('[__wppOpen] hit fast', { activeId, want: jid });
        return true;
      }
      await sleep(80);
      try { active = w.ChatStore?.getActive?.() || w.ChatStore?.getActiveChat?.() || w.ChatStore?.active || null; } catch {}
      activeId = toSer3(active);
    }
    // <<< fim do mini-retry

    const ok = eq(activeId, jid) || okSoft;              // <= linha que você já tinha
    if (debug) console.log('[__wppOpen]', { jid, wid, used, activeId, ok });
    return !!ok;
  };

  
  // =================== send: text + media ===================
  window.__wppSendText = async (jidOrNumber, text, opts={}) => {
    const jid = __ensureJid(jidOrNumber);
    const fn  = WPP?.chat?.sendTextMessage || WPP?.chat?.sendMessage;
    if (!fn) throw new Error('sendTextMessage indisponível');
    return await fn(jid, String(text||''), { createChat:true, ...opts });
  };  

  // =================== tem que ficar abaixo de __wppOpen e __wppSendText ===================
  try { if (!window.top.__wppOpen) window.top.__wppOpen = window.__wppOpen; } catch{}
  try { if (!window.parent.__wppOpen) window.parent.__wppOpen = window.__wppOpen; } catch{}
  try { if (!window.top.__wppSendText) window.top.__wppSendText = window.__wppSendText; } catch{}
  try { if (!window.parent.__wppSendText) window.parent.__wppSendText = window.__wppSendText; } catch{}

  // ======= MOD: sendMedia com createChat + inferência de áudio =======
  window.__wppSendMedia = async ({jid: jidOrNumber, file, filename, caption, forceMime, ptt, type}) => {
    const jid = __ensureJid(jidOrNumber);
    const sendFile = WPP?.chat?.sendFileMessage;
    if (!sendFile) throw new Error('sendFileMessage indisponível');

    let src = file;
    if (typeof file === 'string' && !/^https?:\/\//i.test(file) && !/^data:/i.test(file)) {
      const mime = forceMime || __mimeFromExt(filename||'');
      src = `data:${mime};base64,${file}`;
    }

    const options = { createChat: true }; // <= garante criação do chat
    if (filename) options.filename = filename;
    if (caption)  options.caption  = caption;

    // inferir "audio" para não virar documento em builds chatos
    let inferredMime = forceMime || '';
    if (typeof src === 'string') {
      const m = /^data:([^;]+)/i.exec(src);
      if (m) inferredMime = m[1];
    }
    //const inferredMime = (typeof src === 'string' && /^data:([^;]+)/i.test(src)) ? RegExp.$1 : (forceMime || '');
    if (!type && inferredMime && inferredMime.startsWith('audio/')) options.type = 'audio';
    if (type) options.type = type;

    if (ptt === true) {
      options.ptt      = true;
      options.isPtt    = true;
      options.type     = 'audio';
      options.waveform = true;
    }

    return await sendFile(jid, src, options);
  };

  // açúcares
  window.__wppSendImageUrl    = (jid, url, caption, filename)               => __wppSendMedia({jid, file:url, filename:filename||null, caption});
  window.__wppSendImageB64    = (jid, b64, caption, filename='image.jpg')   => __wppSendMedia({jid, file:b64, filename, caption, forceMime:__mimeFromExt(filename)});
  window.__wppSendVideoUrl    = (jid, url, caption, filename)               => __wppSendMedia({jid, file:url, filename:filename||null, caption});
  window.__wppSendVideoB64    = (jid, b64, caption, filename='video.mp4')   => __wppSendMedia({jid, file:b64, filename, caption, forceMime:__mimeFromExt(filename)});
  window.__wppSendAudioUrl    = (jid, url, ptt=false, filename)             => __wppSendMedia({jid, file:url, filename:filename||null, ptt});
  window.__wppSendAudioB64    = (jid, b64, ptt=false, filename='audio.ogg') => __wppSendMedia({jid, file:b64, filename, forceMime:__mimeFromExt(filename), ptt});
  window.__wppSendDocumentUrl = (jid, url, filename)                        => __wppSendMedia({jid, file:url, filename:filename||null});
  window.__wppSendDocumentB64 = (jid, b64, filename='file.pdf')             => __wppSendMedia({jid, file:b64, filename, forceMime:__mimeFromExt(filename)});

  window.__wppSendVideoNote = async (jidOrNumber, fileOrUrl, filename='note.mp4', mimeHint) => {
    const jid = __ensureJid(jidOrNumber);
    const sendFile = WPP?.chat?.sendFileMessage;
    if (!sendFile) throw new Error('sendFileMessage indisponível');
  
    const guessed = mimeHint || __mimeFromExt(filename || 'note.mp4');
    const src = await __ensureDataUrl(fileOrUrl, guessed);
  
    // Caminho “oficial” (quando existe)
    if (typeof WPP?.chat?.sendVideoMessage === 'function') {
      try {
        return await WPP.chat.sendVideoMessage(jid, src, {
          ptv: true, videoNote: true, filename
        });
      } catch (e) {
        console.warn('[PTV] sendVideoMessage falhou:', e);
      }
    }
  
    // Fallbacks (cobrem diferentes versões do WA-JS)
    const tries = [
      // coloque primeiro o combo mais aceito:
      { filename, type:'video', isPtv:true, ptv:true, videoNote:true, asVideoNote:true, sendMediaAsVideoNote:true },
  
      // variantes vistas em builds antigos/novos:
      { filename, type:'ptv' },
      { filename, type:'video', isPtv:true },
      { filename, type:'video', isVideoMessage:true, isNote:true },
      { filename, videoType:'ptv' },
    ];
  
    for (const opt of tries) {
      try {
        return await sendFile(jid, src, opt);
      } catch (e) {
        console.warn('[PTV] tentativa falhou', opt, e);
      }
    }
  
    console.warn('[PTV] todas as tentativas falharam; enviando como vídeo comum.');
    return await sendFile(jid, src, { filename, type:'video' });
  };
  
  // aliases enxutos (sem duplicar definições)
  window.__wppSendVideoNoteUrl = (jid, urlOrB64, filename='note.mp4') => __wppSendVideoNote(jid, urlOrB64, filename);
  window.__wppSendVideoNoteB64 = (jid, b64,       filename='note.mp4') => __wppSendVideoNote(jid, b64,       filename);

  window.__wppSendVCard = async (to, vcardOrIdOrArray, name='Contato') => {
    const ensure = typeof __ensureJid === 'function'
      ? __ensureJid
      : (s)=>{ s=String(s||'').trim().toLowerCase(); return /@c\.us|@g\.us$/.test(s)?s:/^\d+$/.test(s)?s+'@c.us':s; };
  
    const jid = ensure(to);
  
    try {
      // vCard em texto (BEGIN:VCARD…)
      if (typeof vcardOrIdOrArray === 'string' && /^\s*BEGIN:VCARD/i.test(vcardOrIdOrArray)) {
        return await WPP.chat.sendRawMessage(jid, {
          type: 'vcard',
          body: vcardOrIdOrArray,
          vcardFormattedName: name
        });
      }
  
      // Único ID ou lista de {id,name}
      if (Array.isArray(vcardOrIdOrArray)) {
        const arr = vcardOrIdOrArray.map(x => ({
          id: ensure(x.id || x),
          name: x.name || name
        }));
        return await WPP.chat.sendVCardContactMessage(jid, arr);
      } else {
        return await WPP.chat.sendVCardContactMessage(jid, {
          id: ensure(vcardOrIdOrArray),
          name
        });
      }
    } catch (e) {
      console.error('[__wppSendVCard] erro:', e);
      throw e;
    }
  };
  
  window.__wppSendSticker = async (jidOrNumber, fileOrUrl, filename = 'sticker.webp') => {
    const jid = __ensureJid(jidOrNumber);
    let src = fileOrUrl;
    if (typeof src === 'string' && !/^https?:\/\//i.test(src) && !/^data:/i.test(src)) {
      src = `data:image/webp;base64,${src}`;
    }
    if (typeof WPP?.chat?.sendSticker === 'function') {
      try { return await WPP.chat.sendSticker(jid, src, { filename }); } catch {}
    }
    const tries = [
      { filename, type:'sticker' },
      { filename, isSticker:true },
      { filename, asSticker:true },
      { filename, sendMediaAsSticker:true }
    ];
    for (const opt of tries) { try { return await WPP.chat.sendFileMessage(jid, src, opt); } catch {} }
    return await WPP.chat.sendFileMessage(jid, src, { filename, caption:'' });
  };

  window.__wppSendImage = async (jid, fileOrUrl, caption, filename) => {
    const sendFile = WPP?.chat?.sendFileMessage;
    if (!sendFile) throw new Error('sendFileMessage indisponível');
    let src = fileOrUrl;
    if (typeof src === 'string' && !/^https?:\/\//i.test(src) && !/^data:/i.test(src)) {
      const mime = __mimeFromExt(filename || 'image.jpg');
      const use = mime.startsWith('image/') ? mime : 'image/jpeg';
      src = `data:${use};base64,${src}`;
    }
    if (typeof WPP?.chat?.sendImageMessage === 'function') {
      try { return await WPP.chat.sendImageMessage(jid, src, { caption, filename }); } catch {}
    }
    const tries = [
      { filename, caption, type:'image' },
      { filename, caption, isImage:true },
      { filename, caption, asImage:true },
      { filename, caption, sendMediaAsDocument:false },
    ];
    for (const opts of tries) { try { return await sendFile(jid, src, opts); } catch {} }
    return await sendFile(jid, src, { filename, caption });
  };

  // Arquivar / desarquivar chat
  window.__wppArchiveChat = async (jidOrNumber, archive = true) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    const w = (window.WPP && WPP.whatsapp) || {};

    // caminhos "oficiais" quando existem
    try { if (typeof WPP?.chat?.archiveChat   === 'function') return await WPP.chat.archiveChat(jid, archive); } catch {}
    try { if (typeof WPP?.chat?.setArchive    === 'function') return await WPP.chat.setArchive(jid, archive); } catch {}
    try { if (typeof WPP?.chat?.setArchived   === 'function') return await WPP.chat.setArchived(jid, archive); } catch {}

    // fallbacks por Store/Cmd/Chat
    let chat = null;
    try { chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null; } catch {}
    try { if (!chat && w.ChatStore?.getOrCreate) chat = w.ChatStore.getOrCreate(jid); } catch {}

    if (w.Cmd?.archiveChat)                 return await w.Cmd.archiveChat(chat, archive);
    if (typeof chat?.setArchive   === 'function') return await chat.setArchive(archive);
    if (typeof chat?.setArchived  === 'function') return await chat.setArchived(archive);
    if (typeof chat?.archive      === 'function') return await chat.archive(archive);

    throw new Error('archive_unavailable');
  };

  // Conferir se está arquivado
  window.__wppIsArchived = (jidOrNumber) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    const w = (window.WPP && WPP.whatsapp) || {};
    const c = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null;
    if (!c) return null;
    return !!(c.archive || c.isArchived || c.__x_archive || c.__x_isArchived);
  };

  // Desarquivar conversa
  window.__wppUnarchiveChat = async (jidOrNumber) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');

    if (WPP?.chat?.unarchiveChat) {
      await WPP.chat.unarchiveChat(jid);
      return true;
    }

    const w = WPP?.whatsapp || {};
    let chat = null;
    try { chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null; } catch {}
    if (!chat) { try { await (window.__wppOpen?.(jid) || Promise.resolve()); chat = w.ChatStore?.get?.(jid) || null; } catch {} }

    try { if (chat?.unarchive)      { await chat.unarchive();      return true; } } catch {}
    try { if (chat?.setArchived)    { await chat.setArchived(false); return true; } } catch {}
    try { if (chat?.setArchive)     { await chat.setArchive(false);  return true; } } catch {}
    try { if (w.Cmd?.unarchiveChat) { await w.Cmd.unarchiveChat(chat.id); return true; } } catch {}
    try { if (w.Cmd?.changeChatArchiveStatus) { await w.Cmd.changeChatArchiveStatus(chat, false); return true; } } catch {}

    throw new Error('unarchiveChat_unavailable');
  };

  // Apagar mensagens (suporta strings de id e faz fallback p/ MessageKey)
  window.__wppDeleteMessages = async (jidOrNumber, ids, revoke) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    let list = Array.isArray(ids) ? ids.slice() : (ids ? [ids] : []);
    try {
      // 1) tentativa direta (strings)
      return await WPP.chat.deleteMessages(jid, list, !!revoke);
    } catch (e) {
      // 2) fallback: construir MessageKey a partir do ChatStore
      const w = WPP?.whatsapp || {};
      let chat = null;
      try { chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null; } catch {}
      if (!chat) { try { await (window.__wppOpen?.(jid) || Promise.resolve()); chat = w.ChatStore?.get?.(jid) || null; } catch {} }

      // usamos seu helper interno:
      const msgs = (typeof __msgsOf === 'function') ? __msgsOf(chat) : (chat?.msgs?.models || []);
      const keys = [];

      for (const id of list) {
        let key = null;
        const m = (msgs || []).find(mm => {
          const ser = (mm?.id && (mm.id._serialized || mm.id)) || (mm && mm.key);
          return String(ser || '').toLowerCase() === String(id || '').toLowerCase();
        });

        if (m?.id) key = m.id; // melhor: usa o MessageKey original
        if (!key) {
          // fallback "sintético" (nem sempre necessário, mas ajuda em alguns builds)
          key = { id, fromMe: !!revoke, remoteJid: jid };
        }

        // se for "apagar para todos", só inclua mensagens que são suas
        if (revoke === true) {
          const fromMe = (typeof m?.id?.fromMe !== 'undefined') ? !!m.id.fromMe : (m?.fromMe === true);
          if (fromMe !== true) continue;
        }
        keys.push(key);
      }

      if (!keys.length) return false;
      return await WPP.chat.deleteMessages(jid, keys, !!revoke);
    }
  };

  // === SEEN (marcar como lido) ===
  window.__wppSendSeen = async (jidOrNumber) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    // caminhos oficiais se existirem
    try { if (typeof WPP?.chat?.markIsRead === 'function') return await WPP.chat.markIsRead(jid); } catch {}
    try { if (typeof WPP?.chat?.sendSeen   === 'function') return await WPP.chat.sendSeen(jid);   } catch {}

    // fallbacks internos
    const w = WPP?.whatsapp || {};
    let chat = null;
    try { chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null; } catch {}
    if (!chat) { try { await (window.__wppOpen?.(jid) || Promise.resolve()); chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null; } catch {} }

    try { if (chat?.sendSeen)   return await chat.sendSeen(); } catch {}
    try { if (chat?.markSeen)   return await chat.markSeen(); } catch {}
    try { if (chat?.markAsRead) return await chat.markAsRead(); } catch {}

    // último recurso: abrir o chat (costuma disparar o read receipt)
    try { if (await window.__wppOpen?.(jid)) return true; } catch {}
    return false;
  };

  // === Ler o chat (abrir e opcionalmente marcar como lido) ===
  window.__wppReadChat = async (jidOrNumber, alsoSeen = true) => {
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    try { await window.__wppOpen?.(jid); } catch {}
    if (alsoSeen !== false) {
      try { await window.__wppSendSeen?.(jid); } catch {}
    }
    return true;
  };
  
  // Envia localização como "card de link" (uma única msg com preview).
  window.__wppSendLocation = async (
    jidOrNumber,
    latitude,
    longitude,
    name = '',
    address = '',
    opts = {}
  ) => {
    // preferimos o "card" por padrão (formato Nome - URL em uma única mensagem)
    const style = (opts && opts.style) || 'card';

    // fallback local para __ensureJid
    const ensure = (typeof window.__ensureJid === 'function')
      ? window.__ensureJid
      : (s) => {
          s = String(s || '').trim().toLowerCase();
          if (/@(c|g)\.us$/.test(s)) return s;
          if (/^\d+$/.test(s)) return s + '@c.us';
          return s;
        };

    const jid = ensure(jidOrNumber);
    const lat = Number(latitude), lng = Number(longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      throw new Error('latitude/longitude inválidos');
    }

    // ===== modo nativo (opcional) =====
    if (style === 'native' && typeof WPP?.chat?.sendLocationMessage === 'function') {
      try {
        return await WPP.chat.sendLocationMessage(jid, {
          latitude: lat,
          longitude: lng,
          name,
          address
        });
      } catch (_) { /* cai para o card se falhar */ }
    }

    // ===== modo "card de link" (padrão) =====
    const send = WPP?.chat?.sendTextMessage || WPP?.chat?.sendMessage;
    if (!send) throw new Error('sendTextMessage indisponível');

    const url  = `https://maps.google.com/?q=${lat},${lng}`;
    const text = `${name ? name + ' - ' : ''}${url}`;

    // mensagem única com preview
    return await send(jid, text, { linkPreview: true, createChat: true });
  };
      
  window.__wppCheckNumber = async (num, showConsole = false, opts = {}) => {
    const s0 = String(num || "").trim();
    const hasSuffix  = /(@c\.us|@g\.us)$/i.test(s0);
    const onlyDigits = s0.replace(/\D+/g, "");
    const jid = hasSuffix ? s0.toLowerCase()
                          : (onlyDigits ? (onlyDigits + "@c.us") : s0.toLowerCase());
  
    // shape fixo para o retorno (compatível com seu C#)
    const base = {
      input: s0.replace(/@c\.us$|@g\.us$/i, ""),
      jid,
      exists: false,
      canReceive: null,
      isBusiness: null,
      code: null,
      profileStatus: null,
      displayName: null,
      pushname: null,
      verifiedName: null,
      notifyName: null,
      businessName: null,
      source: "WPP.contact.queryExists",
      error: null
    };
  
    if (!(window.WPP && WPP.contact && typeof WPP.contact.queryExists === "function")) {
      return { ...base, error: "WPP.contact.queryExists não disponível" };
    }
  
    try {
      const r = await WPP.contact.queryExists(jid);
  
      const wid =
        (r?.wid && (r.wid._serialized || r.wid)) ||
        (r?.id  && (r.id._serialized  || r.id))  ||
        (r?.jid && (r.jid._serialized || r.jid)) || null;
  
      const code =
        (typeof r?.status === "number") ? r.status :
        (typeof r?.status === "string" && /^\d+$/.test(r.status)) ? parseInt(r.status, 10) :
        null;
  
      const out = {
        ...base,
        jid: wid || jid,
        exists: !!wid || code === 200,
        isBusiness: r?.biz === true || !!r?.bizInfo,
        businessName: r?.bizInfo?.verifiedName?.name ?? null,
        verifiedName: r?.bizInfo?.verifiedName?.name ?? null,
        profileStatus: (typeof r?.status === "string" && !/^\d+$/.test(r.status)) ? r.status : null,
        code: code,
        canReceive: (typeof r?.canReceiveMessage === "boolean") ? r.canReceiveMessage :
                    (typeof r?.canReceive       === "boolean") ? r.canReceive : null,
        error: null
      };
  
      if (showConsole) console.log("[__wppCheckNumber]", out);
      return out;
    } catch (e) {
      return { ...base, error: String(e && e.message || e) };
    }
  };
  
  try { if (!window.top.__wppCheckNumber) window.top.__wppCheckNumber = window.__wppCheckNumber; } catch {}
  try { if (!window.parent.__wppCheckNumber) window.parent.__wppCheckNumber = window.__wppCheckNumber; } catch {}

  // Adicione isto DEPOIS da sua função atual:
  window.__wppCheckNumberJSON = async (num, showConsole = false, opts = {}) => {
    try {
      const out = await window.__wppCheckNumber(num, showConsole, opts);
      return JSON.stringify(out);
    } catch (e) {
      return JSON.stringify({
        input: String(num || ""),
        jid: null,
        exists: false,
        canReceive: null,
        isBusiness: null,
        code: null,
        profileStatus: null,
        displayName: null,
        pushname: null,
        verifiedName: null,
        notifyName: null,
        businessName: null,
        source: "__wppCheckNumber",
        error: String(e && e.message || e)
      });
    }
  };
  try { if (!window.top.__wppCheckNumberJSON) window.top.__wppCheckNumberJSON = window.__wppCheckNumberJSON; } catch {}
  try { if (!window.parent.__wppCheckNumberJSON) window.parent.__wppCheckNumberJSON = window.__wppCheckNumberJSON; } catch {}

  // Retorna perfil business normalizado em STRINGs
  window.__wppGetBusinessProfileJSON = async (jidOrNumber, showConsole = false) => {
    const s0 = String(jidOrNumber || "").trim();
    const hasSuffix  = /(@c\.us|@g\.us)$/i.test(s0);
    const onlyDigits = s0.replace(/\D+/g, "");
    const jid = hasSuffix ? s0.toLowerCase()
                          : (onlyDigits ? (onlyDigits + "@c.us") : s0.toLowerCase());

    const base = {
      input: s0.replace(/@c\.us$|@g\.us$/i, ""),
      jid,
      category: null,
      description: null,
      email: null,
      website: null,
      error: null,
      source: "getBusinessProfile"
    };

    if (!(window.WPP && WPP.contact && typeof WPP.contact.getBusinessProfile === "function")) {
      return JSON.stringify({ ...base, error: "WPP.contact.getBusinessProfile não disponível" });
    }

    try {
      const prof = await WPP.contact.getBusinessProfile(jid);

      // category pode vir como 'category' ou array 'categories'
      let category = null;
      if (Array.isArray(prof?.categories) && prof.categories.length) {
        category = prof.categories
          .map(c => c?.localized_display_name || c?.name || c?.id)
          .filter(Boolean)
          .join(" / ");
      } else if (typeof prof?.category === "string") {
        category = prof.category;
      }

      /* WEBSITE: pode vir string, array de strings, ou array de OBJETOS */
      let website = null;
      const ws = prof?.websites ?? prof?.website;
      if (Array.isArray(ws)) {
        website = ws
        .map(v => {
          if (typeof v === "string") return v.trim();
          if (v && typeof v === "object") {
            if (typeof v.url   === "string") return v.url.trim();
            if (typeof v.link  === "string") return v.link.trim();
            if (typeof v.value === "string") return v.value.trim();
            const cand = Object.values(v).find(
              x => typeof x === "string" && /^https?:\/\//i.test(x)
            );
            return cand ? cand.trim() : "";
          }
          return "";
        })
        .filter(Boolean)
        .join(", ");

      } else if (typeof ws === "object" && ws) {
        website =
          (typeof ws.url   === "string" && ws.url.trim())   ||
          (typeof ws.link  === "string" && ws.link.trim())  ||
          (typeof ws.value === "string" && ws.value.trim()) ||
          (Object.values(ws).find(
             x => typeof x === "string" && /^https?:\/\//i.test(x)
           ) || null);
      } else if (typeof ws === "string") {
        website = ws.trim();
      }
 
      /* EMAIL: pode vir string ou array/objeto */
      let email = null;
      const em = prof?.email ?? prof?.emails;
      if (Array.isArray(em)) {
        email = em
          .map(v => (typeof v === "string"
            ? v.trim()
            : (v && typeof v === "object" && typeof v.email === "string")
              ? v.email.trim()
              : ""))
          .filter(Boolean)
          .join(", ");
      } else if (typeof em === "object" && em) {
        email = (typeof em.email === "string" && em.email.trim()) ||
        (typeof em.value === "string" && em.value.trim()) ||
        null;
      } else if (typeof em === "string") {
        email = em.trim();
      }
      if (typeof website === "string" && website.includes(",")) {
        website = Array.from(new Set(
          website.split(",").map(s => s.trim()).filter(Boolean)
        )).join(", ");
      }      
      /* MONTE O OBJETO FINAL */
      const out = {
        ...base,
        category,
        description: prof?.description ?? null,
        email,
        website,
        error: null
      };

      if (showConsole) console.log("[__wppGetBusinessProfileJSON]", out);
      return JSON.stringify(out);
    } catch (e) {
      return JSON.stringify({ ...base, error: String(e && e.message || e) });
    }
  };

  try { if (!window.top.__wppGetBusinessProfileJSON) window.top.__wppGetBusinessProfileJSON = window.__wppGetBusinessProfileJSON; } catch {}
  try { if (!window.parent.__wppGetBusinessProfileJSON) window.parent.__wppGetBusinessProfileJSON = window.__wppGetBusinessProfileJSON; } catch {}
    
  // util interno p/ array de mensagens do chat
  function __msgsOf(chat){
    try { if (chat?.msgs?.getModelsArray) return chat.msgs.getModelsArray(); } catch {}
    try { if (Array.isArray(chat?.msgs?.models)) return chat.msgs.models; } catch {}
    try { if (Array.isArray(chat?._msgs?._models)) return chat._msgs._models; } catch {}
    return [];
  }

  // === Responder (com ou sem citação) ===
  window.__wppReply = async (jidOrNumber, text, quotedId=null) => {
    const jid = __ensureJid(jidOrNumber);
    const opts = quotedId ? { quotedMsgId: quotedId } : {};
    const fn = WPP?.chat?.sendTextMessage || WPP?.chat?.sendMessage;
    if (!fn) throw new Error('sendTextMessage indisponível');
    return await fn(jid, String(text||''), opts);
  };

  window.__wppMyJid = () => {
    const c = [
      WPP?.conn?.wid?._serialized || WPP?.conn?.wid,
      WPP?.conn?.user?.id?._serialized || WPP?.conn?.user?.id,
      WPP?.whatsapp?.Conn?.wid?._serialized || WPP?.whatsapp?.Conn?.wid,
      WPP?.conn?.getMyDeviceId?.()
    ].find(Boolean);
    if (!c) return '';
    return String(c).toLowerCase()
      .replace('@s.whatsapp.net','@c.us')
      .replace('@whatsapp.net','@c.us')
      .replace(/:(\d+)(?=@)/,''); // remove :N antes do @
  };

  window.__wppMyNumber = () => (window.__wppMyJid()?.split('@')[0] || '');

  window.__wppMeJSON = async () => {
    const jid = __wppMyJid();
    const out = { jid, number: __wppMyNumber(), pushname:null, notifyName:null, name:null, isBusiness:null };
    try {
      if (WPP?.contact?.getContactById) {
        const c = await WPP.contact.getContactById(jid);
        out.pushname   = c?.pushname || c?.contact?.pushname || null;
        out.notifyName = c?.notifyName || c?.contact?.notifyName || null;
        out.name       = c?.name || c?.contact?.name || c?.formattedName || null;
        out.isBusiness = !!(c?.isBusiness || c?.biz);
      }
    } catch {}
    return out;
  };








})();


// CHATBOT
(function () {
  if (window.__unreadHelpers_v2) return;
  window.__unreadHelpers_v2 = true;

  async function waitForWPP(ms = 8000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      if (window.WPP?.chat?.list && window.WPP?.chat?.getMessages) return true;
      await new Promise(r => setTimeout(r, 100));
    }
    return false;
  }

  const jidOf = (id) => (id && (id._serialized || id)) || '';

  async function collectFromChats(chats, limitPerChat, skipCiphertext) {
    const out = [];
    for (const c of (chats || [])) {
      const jid = jidOf(c.id);
      let ms = [];
      try {
        ms = await WPP.chat.getMessages(jid, {
          onlyUnread: true,
          includeMe: false,
          count: limitPerChat
        });
      } catch (_) {}

      for (const m of (ms || [])) {
        const type = m.type || (m.mimetype?.split('/')?.[0]) || '';
        if (skipCiphertext && type === 'ciphertext') continue;

        const body = m.body || m.caption || m.text ||
          (type==='image'    ? '[imagem]'    :
           type==='video'    ? '[vídeo]'     :
           type==='sticker'  ? '[figurinha]' :
           type==='ptt'      ? '[áudio/ptt]' :
           type==='document' ? '[documento]' : '');

        out.push({
          jid,
          id:   (m.id && (m.id._serialized || m.id)) || '',
          from: m.author || m.from || jid,
          type,
          body: String(body || ''),
          ts:   (m.t || m.timestamp || Date.now())|0
        });
      }
    }
    return out;
  }

  /**
   * @param {number}  limitPerChat    -1=todas, >0 limite por chat
   * @param {boolean} skipCiphertext  true=ignora ciphertext
   * @param {boolean} forceAll        true=varrer todos os chats (ignora onlyWithUnreadMessage)
   */
  window.getAllUnreadMessages = async (limitPerChat = -1, skipCiphertext = false, forceAll = false) => {
    if (!(await waitForWPP())) return [];

    let all = [];
    try { all = await WPP.chat.list(); } catch { all = []; }

    // 1) tenta só com não-lidas
    let chats = [];
    if (!forceAll) {
      try { chats = await WPP.chat.list({ onlyWithUnreadMessage: true }); } catch {}
      if (!chats || chats.length === 0) {
        // 2) fallback por unreadCount do próprio chat
        chats = (all || []).filter(c => (c.unreadCount|0) > 0);
      }
    } else {
      chats = all;
    }

    let out = await collectFromChats(chats, limitPerChat, skipCiphertext);

    // 3) se ainda 0 e não forçado, varre TODOS como último fallback
    if (out.length === 0 && !forceAll) {
      out = await collectFromChats(all, limitPerChat, skipCiphertext);
    }

    try { console.debug('[unread] chats:', chats?.length||0, 'msgs:', out.length); } catch {}
    return out;
  };

  window.getAllUnreadMessagesJSON = async (limitPerChat = -1, skipCiphertext = false, forceAll = false) => {
    try {
      const arr = await window.getAllUnreadMessages(limitPerChat, skipCiphertext, forceAll);
      return JSON.stringify(arr);
    } catch (e) {
      return JSON.stringify({ __err: String(e && (e.message || e)) });
    }
  };
})();



// === JOIN POR CONVITE (grupo) — compatível com build que tem só WPP.group.join ===
(function () {
  window.__wpp_join_v1 = true;

  function extractInviteCode(inv) {
    const s = String(inv || '').trim();
    const m1 = s.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/i);
    if (m1) return m1[1];
    const m2 = s.match(/([A-Za-z0-9]{10,})/);
    return m2 ? m2[1] : '';
  }

  const pickId = (r) =>
    (r && (r._serialized || r.id?._serialized || r.gid?._serialized || r.id || r.gid)) || null;

  const safe = (v) => { try { return JSON.parse(JSON.stringify(v)); } catch { return null; } };

  async function waitForWPP(ms = 12000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      if (window.WPP && (WPP.group || WPP.chat)) return true;
      await new Promise(r => setTimeout(r, 120));
    }
    throw new Error('WPP não disponível');
  }

  // ------- núcleo: tenta join por code e, se falhar por formato, tenta link -------
  async function tryJoinWithFallback(code) {
    if (typeof WPP?.group?.join !== 'function') throw new Error('join_unavailable');

    const tryJoin = async (arg, triedLink) => {
      try {
        const r = await WPP.group.join(arg);
        const rid = pickId(r);
        return { okHint: !!(r?.ok === true || r?.member === true || rid || r), rid, raw: r, err: null };
      } catch(e) {
        const msg = String(e?.message||e||'').toLowerCase();

        // já é membro → sucesso
        if (msg.includes('already') || msg.includes('já participa') || msg.includes('participant'))
          return { okHint: true, rid: null, raw: null, err: null };

        // alguns builds esperam LINK e não CODE → tenta link uma vez
        if (!triedLink) {
          const link = 'https://chat.whatsapp.com/' + code;
          return await tryJoin(link, true);
        }

        return { okHint: false, rid: null, raw: null, err: msg };
      }
    };

    return await tryJoin(code, false);
  }

  // ====== BOOL: o que você usa no app ======
  window.__wppJoinByInviteOK = async function(input){
    await waitForWPP();
    const code = extractInviteCode(input);
    if (!code) return false;

    const { okHint, rid } = await tryJoinWithFallback(code);

    // Se veio id e existe iAmMember, confirma (quando disponível)
    if (rid && typeof WPP?.group?.iAmMember === 'function') {
      try { if (await WPP.group.iAmMember(rid)) return true; } catch {}
    }

    return !!okHint;
  };

  // ====== OBJETO (opcional, coerente com seu formato) ======
  window.__wppJoinByInvite = async function(inviteOrCode){
    await waitForWPP();
    const code = extractInviteCode(inviteOrCode);
    if (!code) return { ok:false, error:'Código/Link inválido' };

    const { okHint, rid, raw } = await tryJoinWithFallback(code);

    let member = null;
    if (rid && typeof WPP?.group?.iAmMember === 'function') {
      try { member = !!(await WPP.group.iAmMember(rid)); } catch {}
    }

    return {
      ok: !!(member === true || okHint),
      gid: rid || null,
      member,
      result: safe(raw),
      info: null // getInviteInfo indisponível no seu build atual
    };
  };

  window.__wppJoinByInviteJSON = async function(inviteOrCode){
    try { return JSON.stringify(await window.__wppJoinByInvite(inviteOrCode)); }
    catch(e){ return JSON.stringify({ ok:false, error:String(e && (e.message||e)) }); }
  };

  // ====== CHECK: degrade com erro claro quando getInviteInfo não existe ======
  window.__wppCheckJoinedFromInvite = async function(inviteOrCode){
    await waitForWPP();
    const code = extractInviteCode(inviteOrCode);
    if (!code) return { ok:false, error:'Código/Link inválido' };

    if (typeof WPP?.group?.getInviteInfo !== 'function') {
      return { ok:false, gid:null, member:null, error:'getInviteInfo_unavailable' };
    }

    let info=null, gid=null, member=null;
    try {
      info = await WPP.group.getInviteInfo(code);
      gid  = pickId(info);
    } catch(e){
      return { ok:false, gid:null, member:null, error:String(e?.message||e) };
    }

    try { if (gid && typeof WPP?.group?.iAmMember === 'function') member = await WPP.group.iAmMember(gid); } catch {}
    return { ok:true, gid, member };
  };

  window.__wppCheckJoinedFromInviteJSON = async function(inviteOrCode){
    try { return JSON.stringify(await window.__wppCheckJoinedFromInvite(inviteOrCode)); }
    catch(e){ return JSON.stringify({ ok:false, error:String(e && (e.message||e)) }); }
  };
})();




(function(){
  if (window.__MY_BOOT?.ver === '1.0.0') return;   // já carregado
  // se existia versão antiga, limpe timers/listeners:
  try {
    if (window.__MY_BOOT?.timer) clearInterval(window.__MY_BOOT.timer);
    if (window.__MY_BOOT?.handler) {
      window.removeEventListener('wh:ready', window.__MY_BOOT.handler);
    }
  } catch {}
  window.__MY_BOOT = { ver: '1.0.0' };

  // ... inicialização aqui ...
  window.__MY_BOOT.handler = (e)=>{/*...*/};
  window.addEventListener('wh:ready', window.__MY_BOOT.handler, { once:true });

  window.__MY_BOOT.timer = setInterval(()=>{/*...*/}, 400);
})();




// typing-utils.js
(function () {
  if (window.__typingFinal_v1) return; window.__typingFinal_v1 = true;

  const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));
  const ensureJid = (s)=>{
    s = String(s||'').trim().toLowerCase();
    if (/@(c|g)\.us$/.test(s)) return s;
    if (/^\d+$/.test(s)) return s + '@c.us';
    return s;
  };

  // -------- núcleo (oficial + fallback DOM) ----------
  async function wppTyping(jidOrNumber, ms=1500, {ensureChat=false}={}) {
    const jid = ensureJid(jidOrNumber);

    // opcional: garantir chat carregado (evita falha do assertGetChat em alguns builds)
    if (ensureChat) {
      try { await (WPP?.chat?.openChatBottom?.(jid) || WPP?.chat?.openChat?.(jid)); } catch {}
    }

    // caminho oficial (manda presença pro destinatário)
    try {
      if (WPP?.chat?.markIsComposing) {
        await WPP.chat.markIsComposing(jid, ms); // auto-pausa ao fim de ms
        return true;
      }
    } catch {}

    // fallback DOM (só anima sua UI; útil quando a API de presença está indisponível)
    try {
      if (window.__wppTypingDOM) { await __wppTypingDOM(jid, ms); return true; }
    } catch {}

    return false;
  }

  // para textos: calcula um tempo humano
  function typingMsFor(text,{cps=8,min=900,max=7000,jitter=0.35}={}) {
    const base = Math.max(min, Math.min(max, (String(text||'').length/Math.max(1,cps))*1000));
    const delta = base * jitter * (Math.random()*2-1);
    return Math.round(base + delta);
  }

  // enviar texto com “digitando…”
  async function wppSendTextTyping(jidOrNumber, text, opts={}) {
    const jid = ensureJid(jidOrNumber);
    const ms  = Number.isFinite(opts.ms) ? opts.ms : typingMsFor(text, opts);
    await wppTyping(jid, ms, {ensureChat:false});
    const send = WPP?.chat?.sendTextMessage || WPP?.chat?.sendMessage;
    return await send(jid, String(text||''), { createChat:true });
  }

  // manter digitando por longos períodos (repulsa a presença a cada ~3.5s)
  async function wppTypingHold(jidOrNumber, totalMs=8000) {
    const jid = ensureJid(jidOrNumber);
    const step = 3500;
    const end = Date.now() + totalMs;
    while (Date.now() < end) {
      try { await WPP.chat.markIsComposing?.(jid, step+300); } catch {}
      await sleep(step);
    }
    try { await WPP.chat.markIsPaused?.(jid); } catch {}
    return true;
  }

  // expõe no window
  window.wppTyping = wppTyping;
  window.wppSendTextTyping = wppSendTextTyping;
  window.wppTypingHold = wppTypingHold;
})();

(function () {
  if (window.__recordingHelpers_v1) return; window.__recordingHelpers_v1 = true;

  const sleep = (ms)=>new Promise(r=>setTimeout(r, ms));
  const _ensure = (typeof __ensureJid==='function')
    ? __ensureJid
    : (s)=>{ s=String(s||'').trim().toLowerCase();
             if(/@(c|g)\.us$/.test(s)) return s;
             if(/^\d+$/.test(s)) return s+'@c.us';
             return s; };

  async function __wppRecording(jidOrNumber, ms=1800){
    const jid = _ensure(jidOrNumber);
    try { await (window.__wppOpen?.(jid) || Promise.resolve()); } catch {}
    const w = WPP?.whatsapp || {};

    const start = async () => {
      try { if (WPP?.chat?.markIsRecording) return await WPP.chat.markIsRecording(jid); } catch {}
      try { if (WPP?.chat?.setRecording)     return await WPP.chat.setRecording(jid, true); } catch {}
      try {
        const chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null;
        if (chat?.sendRecording)             return await chat.sendRecording();
        if (chat?.sendChatStateRecording)    return await chat.sendChatStateRecording();
        if (w.SendChatState?.sendChatStateRecording)
          return await w.SendChatState.sendChatStateRecording(chat||jid);
      } catch {}
      // último fallback → presença de texto
      try { if (WPP?.chat?.markIsComposing) return await WPP.chat.markIsComposing(jid); } catch {}
    };

    const stop = async () => {
      try { if (WPP?.chat?.markIsPaused)     return await WPP.chat.markIsPaused(jid); } catch {}
      try { if (WPP?.chat?.setRecording)     return await WPP.chat.setRecording(jid, false); } catch {}
      try {
        const chat = w.ChatStore?.get?.(jid) || w.ChatStore?.find?.(jid) || null;
        if (chat?.sendPaused)                return await chat.sendPaused();
        if (chat?.sendChatStatePaused)       return await chat.sendChatStatePaused();
        if (w.SendChatState?.sendChatStatePaused)
          return await w.SendChatState.sendChatStatePaused(chat||jid);
      } catch {}
    };

    const end = Date.now() + ms;
    while (true) {
      await start();
      const left = end - Date.now();
      if (left <= 0) break;
      await sleep(Math.min(3500, left)); // “ping” para não cair o status
    }
    await stop();
    return true;
  }

  // wrappers: “mostrar gravando” e depois enviar
  window.__wppRecording = __wppRecording;

  window.__wppSendVideoNoteRecording = async (jid, fileOrUrl, filename='note.mp4', mimeHint, ms=1800) => {
    try { await __wppRecording(jid, ms); } catch {}
    return await __wppSendVideoNote(jid, fileOrUrl, filename, mimeHint);
  };
})();


// === envio unificado de áudio (PTT vs normal) ===
(function () {
  if (window.__wppSendAudioUnified_v1) return; window.__wppSendAudioUnified_v1 = true;

  // ======= MOD: inclui .oga =======
  const guessMimeFromName = (name, { ptt=false } = {}) => {
    const n = String(name || '').toLowerCase();
    if (n.endsWith('.mp3')) return 'audio/mpeg';
    if (n.endsWith('.ogg') || n.endsWith('.opus') || n.endsWith('.oga')) return 'audio/ogg; codecs=opus';
    // fallback esperto:
    return ptt ? 'audio/ogg; codecs=opus' : 'audio/mpeg';
  };

  const normalizeFilename = (filename, { ptt=false } = {}) => {
    let fn = String(filename || '').trim();
    if (!fn) return ptt ? 'audio.ogg' : 'audio.mp3';
    return fn;
  };

  // API única:
  // __wppSendAudioUnified(jidOrNumber, fileOrUrl, { ptt, filename, showRecordingMs })
  window.__wppSendAudioUnified = async (jidOrNumber, fileOrUrl, opts = {}) => {
    const ptt = !!opts.ptt;
    const jid = (typeof __ensureJid === 'function') ? __ensureJid(jidOrNumber) : String(jidOrNumber||'');
    if (!jid) throw new Error('jid inválido');

    const filename = normalizeFilename(opts.filename, { ptt });
    const mimeHint = guessMimeFromName(filename, { ptt });

    // garante data URL se vier base64 cru / blob / typed array
    const src = await (typeof __ensureDataUrl === 'function'
      ? __ensureDataUrl(fileOrUrl, mimeHint)
      : Promise.resolve(fileOrUrl));

    // opcional: mostra "gravando..." antes de enviar PTT
    const ms = Number(opts.showRecordingMs)||0;
    if (ptt && ms > 0 && typeof window.__wppRecording === 'function') {
      try { await window.__wppRecording(jid, ms); } catch {}
    }

    // 1ª rota: se existir API dedicada, tenta ela
    if (ptt && typeof WPP?.chat?.sendVoiceMessage === 'function') {
      try {
        return await WPP.chat.sendVoiceMessage(jid, src, { filename, ptt: true, createChat:true });
      } catch (e) {
        console.warn('[sendVoiceMessage falhou, fallback p/ sendFileMessage]', e);
      }
    }

    // fallback universal
    const sendFile = WPP?.chat?.sendFileMessage;
    if (!sendFile) throw new Error('sendFileMessage indisponível');

    const options = { filename, createChat:true };
    // garantir bolha de áudio mesmo quando NÃO for ptt:
    const inferredMime = (typeof src === 'string' && /^data:([^;]+)/i.test(src)) ? RegExp.$1 : (mimeHint || '');
    if (inferredMime && inferredMime.startsWith('audio/')) options.type = 'audio';

    if (ptt) {
      options.ptt = true;
      options.isPtt = true;
      options.type = 'audio';
      options.waveform = true;
    }

    return await sendFile(jid, src, options);
  };

  // ======= MOD: exportar para top/parent =======
  try { if (!window.top.__wppSendAudioUnified) window.top.__wppSendAudioUnified = window.__wppSendAudioUnified; } catch {}
  try { if (!window.parent.__wppSendAudioUnified) window.parent.__wppSendAudioUnified = window.__wppSendAudioUnified; } catch {}

})();


// === Limpar/Deletar conversas de GRUPOS (WPP Connect WA-JS) ===
// Uso rápido (console):
//   await zapClearGroupChat('1203630xxxxxxxx-yy', { keepStarred:false }); // limpa tudo
//   await zapClearGroupChat('1203630xxxxxxxx-yy', { removeThread:true }); // limpa e remove da lista
//   await zapClearGroups(['1203...-1', '1203...-2'], { keepStarred:false });

// 🔒 Versão única e idempotente
(function(){
  if (window.zapClearGroupChat?.__v >= 2 && window.zapClearGroups?.__v >= 2) return;

  // Wrappers se faltar API direta
  window.__wppClearChat  = window.__wppClearChat  || (async (jid, keepStarred=true) => {
    if (WPP?.chat?.clearChat) return await WPP.chat.clearChat(jid, { keepStarred: !!keepStarred });
    if (WPP?.chat?.clear)     return await WPP.chat.clear(jid, !!keepStarred);
    throw new Error('clearChat_unavailable');
  });
  window.__wppDeleteChat = window.__wppDeleteChat || (async (jid) => {
    if (WPP?.chat?.deleteChat) return await WPP.chat.deleteChat(jid);
    if (WPP?.chat?.delete)     return await WPP.chat.delete(jid);
    throw new Error('deleteChat_unavailable');
  });

  const ensureGroupJid = (id)=>{
    if(!id) throw new Error('groupId vazio');
    const s = String(id).trim().toLowerCase();
    if (s.endsWith('@g.us') || s.endsWith('@c.us')) return s;
    return s + '@g.us';
  };

  async function zapClearGroupChat(groupId, opts){
    const o = Object.assign({ keepStarred:true, removeThread:false }, opts || {});
    const jid = ensureGroupJid(groupId);

    await __wppClearChat(jid, !!o.keepStarred);

    if (o.removeThread) {
      await __wppDeleteChat(jid);
      return { ok:true, removed:true };
    }
    return { ok:true, removed:false };
  }
  zapClearGroupChat.__v = 2;

  async function zapClearGroups(groupIds, opts){
    const out = { ok:true, total:0, success:0, fail:[], results:[] };
    for (const id of (groupIds || [])){
      out.total++;
      try{
        const r = await zapClearGroupChat(id, opts);
        out.success++;
        out.results.push({ id, ...r });
      }catch(e){
        out.fail.push({ id, error: String(e) });
      }
    }
    return out;
  }
  zapClearGroups.__v = 2;

  window.zapClearGroupChat = zapClearGroupChat;
  window.zapClearGroups    = zapClearGroups;
})();


(function(){
  // 1) Normalizador único e robusto
  function __normJid(j){
    const s = (j?._serialized ||
               (j?.server && j?.user && (j.user + '@' + j.server)) ||
               j?.id?._serialized || j?.id ||
               j?.wid?._serialized || j?.wid ||
               j?.__x_id?._serialized || j?.__x_id ||
               (typeof j?.toString==='function' ? j.toString() : j) || ""
    ).toString().trim().toLowerCase();
    if (!s) return "";
    if (s.endsWith("@g.us")) return s;
    const s2 = s.replace("@s.whatsapp.net","@c.us").replace("@whatsapp.net","@c.us");
    if (s2.endsWith("@c.us")) return s2;
    if (/^\d{6,20}$/.test(s2)) return s2 + "@c.us";
    return s2;
  }

  // 2) Detector de capacidades
  async function __cap(){
    const cap = {
      has_WPP_chat_getActive: !!(window.WPP?.chat?.getActive),
      has_WPP_ui_getActiveChat: !!(window.WPP?.ui?.getActiveChat),
      has_ChatStore: !!(window.WPP?.whatsapp?.ChatStore),
      has_ChatStore_getActive: typeof window.WPP?.whatsapp?.ChatStore?.getActive === 'function',
      has_ChatStore_getActiveChat: typeof window.WPP?.whatsapp?.ChatStore?.getActiveChat === 'function',
      has_ChatStore_active: !!(window.WPP?.whatsapp?.ChatStore?.active),
    };
    return cap;
  }

  // 3) Pega o chat ativo pelo primeiro caminho disponível
  async function __getActiveChat(){
    try { if (WPP?.chat?.getActive) { const c = await WPP.chat.getActive(); if (c) return c; } } catch {}
    try { if (WPP?.ui?.getActiveChat) { const c = WPP.ui.getActiveChat(); if (c) return c; } } catch {}
    try {
      const cs = WPP?.whatsapp?.ChatStore;
      if (cs){
        if (typeof cs.getActive === 'function'){ const c = cs.getActive(); if (c) return c; }
        if (typeof cs.getActiveChat === 'function'){ const c = cs.getActiveChat(); if (c) return c; }
        if (cs.active) return cs.active;
      }
    } catch {}
    return null;
  }

  // 4) Diagnóstico legível para você (opcional)
  async function __wppDiagActive(){
    const cap = await __cap();
    const c = await __getActiveChat();
    const idCandidates = {
      'c.id': c?.id,
      'c.id._serialized': c?.id?._serialized,
      'c.wid': c?.wid,
      'c.wid._serialized': c?.wid?._serialized,
      'c.__x_id': c?.__x_id,
      'c.__x_id._serialized': c?.__x_id?._serialized,
      'c.toString()': (c && typeof c.toString==='function') ? c.toString() : undefined
    };
    const chosen = __normJid(c?.id?._serialized || c?.wid?._serialized || c?.id || c?.wid || c?.__x_id?._serialized || c?.__x_id || (c && c.toString && c.toString()));
    return {cap, hasActive: !!c, idCandidates, normalizedChosen: chosen};
  }

  // 5) API final estável
  async function __wppGetActiveJID(){
    const c = await __getActiveChat();
    if (!c) return "";
    const anyId = c?.id?._serialized || c?.wid?._serialized || c?.id || c?.wid || c?.__x_id?._serialized || c?.__x_id || (typeof c?.toString==='function' ? c.toString() : c);
    return __normJid(anyId) || "";
  }

  // expõe
  window.__wppDiagActive = __wppDiagActive;
  window.__wppGetActiveJID = __wppGetActiveJID;
  window.__normJid = __normJid;
})();


// === MENCIONAR SILENCIOSO (badge de @ no WhatsApp, corpo "limpo") ===
//   await window.__wppMentionSilent('1203...@g.us', ['5511999999999@c.us','5511888888888'], { text: '\u200B' });
// - groupId: jid do grupo (com ou sem @g.us — eu normalizo)
// - people:  string ou array; aceita números crus ou ...@c.us
// - opts.text: texto opcional; padrão = '\u200B' (zero-width) para corpo invisível
// === MENCIONAR SILENCIOSO (badge de @, corpo "limpo") ===
(function () {
  if (window.__wppMentionSilent_v1) return; // idempotente
  window.__wppMentionSilent_v1 = true;

  function normGroup(s) {
    s = String(s || '').trim().toLowerCase();
    if (!s) throw new Error('groupId vazio');
    if (!/@(g|c)\.us$/.test(s)) s += '@g.us';
    return s.replace('@c.us', '@g.us');
  }
  function toArray(x) { return Array.isArray(x) ? x : (x == null ? [] : [x]); }
  function toCUs(v) {
    v = String(v || '').trim().toLowerCase();
    if (!v) return null;
    if (/@(c|g)\.us$/.test(v)) return v.replace('@g.us','@c.us');
    const digits = v.replace(/\D+/g,'');
    return digits ? digits + '@c.us' : null;
  }

  // sua API pública
  function __wppMentionSilent(groupId, people, opts) {
    const gid = normGroup(groupId);
    const mentionedList = toArray(people).map(toCUs).filter(Boolean);
    if (!mentionedList.length) throw new Error('lista de menções vazia');

    const text = (opts && opts.text != null) ? String(opts.text) : '\u200B';
    const send = (window.WPP?.chat?.sendTextMessage || window.WPP?.chat?.sendMessage);
    if (!send) throw new Error('sendTextMessage indisponível (WPP não pronto?)');

    const options = { createChat: true, detectMentioned: false, mentionedList };
    return send(gid, text, options);
  }

  // expõe igual às outras funções do arquivo
  window.__wppMentionSilent = __wppMentionSilent;
})();






// === WPP Connect - verificador robusto (compatível c/ seu C#) ===
(function () {
  const g = window.top || window;

  // ---------------------- utils ----------------------
  const toJid = (n) => {
    n = String(n||'').trim();
    if (/@(c|g)\.us$/i.test(n)) return n.toLowerCase();
    const d = n.replace(/\D+/g,'');
    return (d || n).toLowerCase() + '@c.us';
  };
  const __raw = (s) => String(s||'').replace(/\D+/g,'');
  const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));

  // ----------------- queryExists (segura) -----------------
  async function __queryExistsSafe(jid){
    const out = { ok:false, wid:null, biz:null, src:'queryExists', err:null };
    try {
      if (typeof g.WPP?.contact?.queryExists !== 'function') {
        out.src = 'qe_unavailable';
        return out;
      }
      const r = await g.WPP.contact.queryExists(jid);
      const wid =
        (r?.wid && (r.wid._serialized || r.wid)) ||
        (r?.id  && (r.id._serialized  || r.id))  ||
        (r?.jid && (r.jid._serialized || r.jid)) || null;
      out.ok  = !!(wid || r === true);
      out.wid = wid || null;

      if (r && typeof r.biz === 'boolean') out.biz = r.biz;
      else if (r && r.bizInfo)            out.biz = true;

      return out;
    } catch (e) {
      const msg = String(e?.message || e || '').toLowerCase();
      if (msg.includes('islid') || msg.includes('createuserwid')) {
        out.src = 'qe_error';
        out.err = msg;
        return out;
      }
      out.src = 'qe_error';
      out.err = msg;
      return out;
    }
  }

  // --------------- pega modelo de contato (fallback) ---------------
  async function __getContactModel(jid){
    try {
      const get = g.WPP?.contact?.getContact ?? g.WPP?.contact?.get;
      if (get) {
        const c = await get(jid);
        if (c) return c;
      }
    } catch {}
    try {
      const c = g.WPP?.whatsapp?.ContactStore?.get?.(jid);
      if (c) return c;
    } catch {}
    return null;
  }

  // --------------- detectar Business (só flags oficiais) ---------------
  async function __detectIsBusiness(jid){
    try {
      const c = await __getContactModel(jid);
      if (typeof c?.isBusiness === 'boolean') return c.isBusiness;
      if (typeof c?.biz === 'boolean')        return c.biz;
    } catch {}
    try {
      const qe = await __queryExistsSafe(jid);
      if (qe.biz === true)  return true;
      if (qe.biz === false) return false;
    } catch {}
    return false;
  }

  // ------------ existência estrita (sem usar getStatus) ------------
  async function __existsStrict(jid){
    const qe = await __queryExistsSafe(jid);
    if (qe.ok) return { exists:true, src: qe.src };

    try {
      const pfp = await g.WPP?.contact?.getProfilePictureUrl?.(jid);
      if (pfp && typeof pfp === 'string' && /^https?:\/\//i.test(pfp)) {
        return { exists:true, src:'pfp' };
      }
    } catch {}

    try {
      const fn = g.WPP?.contact?.getBusinessProfile || g.WPP?.business?.getBusinessProfile;
      if (fn) {
        const bp = await fn(jid);
        if (bp && (
          bp?.verifiedName?.name || bp?.title || bp?.category ||
          (Array.isArray(bp?.categories) && bp.categories.length) ||
          bp?.website || (Array.isArray(bp?.websites) && bp.websites.length) ||
          bp?.email   || (Array.isArray(bp?.emails)   && bp.emails.length)
        )) {
          return { exists:true, src:'biz_profile' };
        }
      }
    } catch {}

    return { exists:false, src: qe.src || 'none' };
  }

  // ----------------- monta infos do número -----------------
  async function wppNumberInfo(number) {
    const jid = toJid(number);

    const ex = await __existsStrict(jid);
    if (!ex.exists) {
      return {
        jid, exists:false, isBusiness:null,
        displayName:null, pushname:null, notifyName:null,
        profileStatus:null, verifiedName:null, businessName:null,
        profilePicUrl:null, source:ex.src
      };
    }

    let contact=null, pfp=null, profileStatus=null;
    try { contact = await __getContactModel(jid); } catch {}
    try { pfp     = await g.WPP?.contact?.getProfilePictureUrl?.(jid); } catch {}
    try {
      const s = await g.WPP?.contact?.getStatus?.(jid);
      profileStatus = (s && typeof s.status === 'string') ? s.status
                      : (typeof s === 'string' ? s : null);
    } catch {}

    const isBiz = await __detectIsBusiness(jid);

    return {
      jid,
      exists: true,
      isBusiness: isBiz,
      displayName: contact?.name || contact?.formattedName || null,
      pushname:    contact?.pushname || null,
      notifyName:  contact?.notifyName || null,
      profileStatus,
      verifiedName: null,
      businessName: null,
      profilePicUrl: pfp || null,
      source: ex.src
    };
  }

  // ----------------- API que seu C# chama -----------------
  g.__wppCheckNumber = async (num, showConsole = false, opts = {}) => {
    const s0  = String(num||'').trim();
    const jid = toJid(s0);
    const id  = __raw(s0) || __raw(jid) || s0;
    const wantBiz = opts?.includeBusinessProfile === true;

    const base = {
      id,
      numberExists: false,
      businessCategory: null,
      businessEmail: null,
      businessWebsite: null,

      input: s0,
      jid,
      exists: false,
      canReceive: null,
      isBusiness: null,
      code: null,
      profileStatus: null,
      displayName: null,
      pushname: null,
      verifiedName: null,
      notifyName: null,
      businessName: null,
      source: 'none',
      error: null
    };

    try {
      const info = await wppNumberInfo(jid);
      if (!info.exists) {
        const outNF = { ...base, source: info.source || base.source };
        if (showConsole) { try { console.table([outNF]); } catch {} }
        return outNF;
      }

      const out = {
        ...base,
        exists: true,
        numberExists: true,
        isBusiness: !!info.isBusiness,
        displayName: info.displayName || null,
        pushname: info.pushname || null,
        notifyName: info.notifyName || null,
        profileStatus: info.profileStatus || null,
        verifiedName: info.verifiedName || null,
        businessName: info.businessName || null,
        source: info.source || base.source
      };

      if (wantBiz) {
        try {
          const fn = g.WPP?.contact?.getBusinessProfile || g.WPP?.business?.getBusinessProfile;
          if (fn) {
            const bp = await fn(jid);

            // categoria amigável
            let cat = null;
            if (Array.isArray(bp?.categories) && bp.categories.length) {
              cat = bp.categories
                .map(c => c?.localized_display_name || c?.name || c?.id)
                .filter(Boolean)
                .join(' / ');
            } else if (typeof bp?.category === 'string') {
              cat = bp.category;
            }

            // website
            let site = null;
            const ws = bp?.websites ?? bp?.website;
            if (Array.isArray(ws)) {
              site = ws.map(v => {
                if (typeof v === 'string') return v.trim();
                if (v && typeof v === 'object') return (v.url || v.link || v.value || '').toString().trim();
                return '';
              }).filter(Boolean).join(', ');
            } else if (typeof ws === 'object' && ws) {
              site = (ws.url || ws.link || ws.value || '').toString().trim() || null;
            } else if (typeof ws === 'string') {
              site = ws.trim();
            }
            if (typeof site === 'string' && site.includes(',')) {
              site = Array.from(new Set(site.split(',').map(s => s.trim()).filter(Boolean))).join(', ');
            }

            // email
            let email = null;
            const em = bp?.email ?? bp?.emails;
            if (Array.isArray(em)) {
              email = em.map(v => (typeof v === 'string'
                ? v.trim()
                : (v && typeof v === 'object' && typeof v.email === 'string')
                  ? v.email.trim()
                  : ''))
                .filter(Boolean)
                .join(', ');
            } else if (typeof em === 'object' && em) {
              email = (em.email || em.value || '').toString().trim() || null;
            } else if (typeof em === 'string') {
              email = em.trim();
            }

            out.businessCategory = cat || null;
            out.businessWebsite  = site || null;
            out.businessEmail    = email || null;
          }
        } catch {}
      }

      if (showConsole) { try { console.table([out]); } catch {} }
      return out;
    } catch (e) {
      return { ...base, error: String(e && (e.message||e)), source:'exception' };
    }
  };

  g.__wppCheckNumberJSON = async (num, showConsole = false, opts = {}) => {
    try {
      const out = await g.__wppCheckNumber(num, showConsole, opts);
      return JSON.stringify(out);
    } catch (e) {
      return JSON.stringify({
        input: String(num||''),
        jid: null, exists:false, canReceive:null, isBusiness:null, code:null,
        profileStatus:null, displayName:null, pushname:null, verifiedName:null,
        notifyName:null, businessName:null, source:'__wppCheckNumber', error:String(e && (e.message||e))
      });
    }
  };

  // === NOVO: endpoint que seu C# usa para buscar os DETALHES do perfil business ===
  g.__wppGetBusinessProfileJSON = async (jidOrNumber, showConsole = false) => {
    const jid = toJid(jidOrNumber);
    const base = { input: String(jidOrNumber||''), jid, category:null, description:null, email:null, website:null, error:null, source:'businessProfile' };
    try{
      const fn = g.WPP?.contact?.getBusinessProfile || g.WPP?.business?.getBusinessProfile;
      if (!fn) return JSON.stringify({ ...base, error:'getBusinessProfile não disponível' });

      const bp = await fn(jid);

      // categoria
      let category = null;
      if (Array.isArray(bp?.categories) && bp.categories.length) {
        category = bp.categories
          .map(c => c?.localized_display_name || c?.name || c?.id)
          .filter(Boolean)
          .join(' / ');
      } else if (typeof bp?.category === 'string') {
        category = bp.category;
      }

      // website
      let website = null;
      const ws = bp?.websites ?? bp?.website;
      if (Array.isArray(ws)) {
        website = ws.map(v => {
          if (typeof v === 'string') return v.trim();
          if (v && typeof v === 'object') return (v.url || v.link || v.value || '').toString().trim();
          return '';
        }).filter(Boolean).join(', ');
      } else if (typeof ws === 'object' && ws) {
        website = (ws.url || ws.link || ws.value || '').toString().trim() || null;
      } else if (typeof ws === 'string') {
        website = ws.trim();
      }
      if (typeof website === 'string' && website.includes(',')) {
        website = Array.from(new Set(website.split(',').map(s => s.trim()).filter(Boolean))).join(', ');
      }

      // email
      let email = null;
      const em = bp?.email ?? bp?.emails;
      if (Array.isArray(em)) {
        email = em.map(v => (typeof v === 'string'
          ? v.trim()
          : (v && typeof v === 'object' && typeof v.email === 'string')
            ? v.email.trim()
            : ''))
          .filter(Boolean)
          .join(', ');
      } else if (typeof em === 'object' && em) {
        email = (em.email || em.value || '').toString().trim() || null;
      } else if (typeof em === 'string') {
        email = em.trim();
      }

      const out = {
        ...base,
        category: category || null,
        description: bp?.description || null,
        email: email || null,
        website: website || null
      };
      if (showConsole) console.log('[biz]', out);
      return JSON.stringify(out);
    }catch(e){
      return JSON.stringify({ ...base, error:String(e && (e.message||e)) });
    }
  };

  // idempotente
  try {
    if (!g.top.__wppCheckNumberJSON)     g.top.__wppCheckNumberJSON     = g.__wppCheckNumberJSON;
    if (!g.top.__wppCheckNumber)         g.top.__wppCheckNumber         = g.__wppCheckNumber;
    if (!g.top.__wppGetBusinessProfileJSON) g.top.__wppGetBusinessProfileJSON = g.__wppGetBusinessProfileJSON;
  } catch {}
})();



// === WPP Connect - verificador robusto (compatível c/ seu C#) ===
(function () {
  const g = window.top || window;

  // ---------------------- utils ----------------------
  const toJid = (n) => {
    n = String(n||'').trim();
    if (/@(c|g)\.us$/i.test(n)) return n.toLowerCase();
    const d = n.replace(/\D+/g,'');
    return (d || n).toLowerCase() + '@c.us';
  };
  const __raw = (s) => String(s||'').replace(/\D+/g,'');
  const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));

  // ----------------- queryExists (segura) -----------------
  async function __queryExistsSafe(jid){
    const out = { ok:false, wid:null, biz:null, src:'queryExists', err:null };
    try {
      if (typeof g.WPP?.contact?.queryExists !== 'function') {
        out.src = 'qe_unavailable';
        return out;
      }
      const r = await g.WPP.contact.queryExists(jid);
      const wid =
        (r?.wid && (r.wid._serialized || r.wid)) ||
        (r?.id  && (r.id._serialized  || r.id))  ||
        (r?.jid && (r.jid._serialized || r.jid)) || null;
      out.ok  = !!(wid || r === true);
      out.wid = wid || null;

      // sinalização de business quando existir
      if (r && typeof r.biz === 'boolean') out.biz = r.biz;
      else if (r && r.bizInfo)            out.biz = true;

      return out;
    } catch (e) {
      const msg = String(e?.message || e || '').toLowerCase();
      if (msg.includes('islid') || msg.includes('createuserwid')) {
        out.src = 'qe_error';
        out.err = msg;
        return out;
      }
      out.src = 'qe_error';
      out.err = msg;
      return out;
    }
  }

  // --------------- pega modelo de contato (fallback) ---------------
  async function __getContactModel(jid){
    try {
      const get = g.WPP?.contact?.getContact ?? g.WPP?.contact?.get;
      if (get) {
        const c = await get(jid);
        if (c) return c;
      }
    } catch {}
    try {
      const c = g.WPP?.whatsapp?.ContactStore?.get?.(jid);
      if (c) return c;
    } catch {}
    return null;
  }

  // --------------- detectar Business (só flags oficiais) ---------------
  async function __detectIsBusiness(jid){
    try {
      const c = await __getContactModel(jid);
      if (typeof c?.isBusiness === 'boolean') return c.isBusiness;
      if (typeof c?.biz === 'boolean')        return c.biz; // alguns builds
    } catch {}
    try {
      const qe = await __queryExistsSafe(jid);
      if (qe.biz === true)  return true;
      if (qe.biz === false) return false;
    } catch {}
    return false;
  }

  // ------------ existência estrita (sem usar getStatus p/ decidir) ------------
  async function __existsStrict(jid){
    const qe = await __queryExistsSafe(jid);
    if (qe.ok) return { exists:true, src: 'queryExists' };

    // 2) foto de perfil → existe
    try {
      const pfp = await g.WPP?.contact?.getProfilePictureUrl?.(jid);
      if (pfp && typeof pfp === 'string' && /^https?:\/\//i.test(pfp)) {
        return { exists:true, src:'pfp' };
      }
    } catch {}

    // 3) perfil business com campos relevantes → existe
    try {
      const fn = g.WPP?.contact?.getBusinessProfile || g.WPP?.business?.getBusinessProfile;
      if (fn) {
        const bp = await fn(jid);
        if (bp && (
          bp?.verifiedName?.name || bp?.title || bp?.category ||
          (Array.isArray(bp?.categories) && bp.categories.length) ||
          bp?.website || (Array.isArray(bp?.websites) && bp.websites.length) ||
          bp?.email   || (Array.isArray(bp?.emails)   && bp.emails.length)
        )) {
          return { exists:true, src:'biz_profile' };
        }
      }
    } catch {}

    return { exists:false, src: qe.src || 'none' };
  }

  // ----------------- monta infos do número -----------------
  async function wppNumberInfo(number) {
    const jid = toJid(number);

    // existência
    const ex = await __existsStrict(jid);
    if (!ex.exists) {
      return {
        jid, exists:false, isBusiness:null,
        displayName:null, pushname:null, notifyName:null,
        profileStatus:null, verifiedName:null, businessName:null,
        profilePicUrl:null, source:ex.src
      };
    }

    // nomes/foto (best-effort)
    let contact=null, pfp=null, profileStatus=null;
    try { contact = await __getContactModel(jid); } catch {}
    try { pfp     = await g.WPP?.contact?.getProfilePictureUrl?.(jid); } catch {}
    try {
      const s = await g.WPP?.contact?.getStatus?.(jid);
      profileStatus = (s && typeof s.status === 'string') ? s.status
                      : (typeof s === 'string' ? s : null);
    } catch {}

    // business via flags oficiais
    const isBiz = await __detectIsBusiness(jid);

    return {
      jid,
      exists: true,
      isBusiness: isBiz,
      displayName: contact?.name || contact?.formattedName || null,
      pushname:    contact?.pushname || null,
      notifyName:  contact?.notifyName || null,
      profileStatus,
      verifiedName: null,
      businessName: null,
      profilePicUrl: pfp || null,
      source: ex.src
    };
  }

  // ----------------- API que seu C# chama -----------------
  g.__wppCheckNumber = async (num, showConsole = false, opts = {}) => {
    const s0  = String(num||'').trim();
    const jid = toJid(s0);
    const id  = __raw(s0) || __raw(jid) || s0;
    const wantBiz = opts?.includeBusinessProfile === true;

    const base = {
      id,
      numberExists: false,         // espelho de exists p/ grid/planilha
      businessCategory: null,
      businessEmail: null,
      businessWebsite: null,

      input: s0,
      jid,
      exists: false,
      canReceive: null,
      isBusiness: null,
      code: null,
      profileStatus: null,
      displayName: null,
      pushname: null,
      verifiedName: null,
      notifyName: null,
      businessName: null,
      source: 'none',
      error: null
    };

    try {
      const info = await wppNumberInfo(jid);
      if (!info.exists) {
        const outNF = { ...base, source: info.source || base.source };
        if (showConsole) { try { console.table([outNF]); } catch {} }
        return outNF;
      }

      const out = {
        ...base,
        exists: true,
        numberExists: true,
        isBusiness: !!info.isBusiness,
        displayName: info.displayName || null,
        pushname: info.pushname || null,
        notifyName: info.notifyName || null,
        profileStatus: info.profileStatus || null,
        verifiedName: info.verifiedName || null,
        businessName: info.businessName || null,
        source: info.source || base.source
      };

      // Perfil business detalhado (se pedirem explicitamente)
      if (wantBiz) {
        try {
          const fn = g.WPP?.contact?.getBusinessProfile || g.WPP?.business?.getBusinessProfile;
          if (fn) {
            const bp = await fn(jid);

            // categoria user-friendly
            let category = null;
            if (Array.isArray(bp?.categories) && bp.categories.length) {
              category = bp.categories
                .map(c => c?.localized_display_name || c?.name || c?.id)
                .filter(Boolean)
                .join(' / ');
            } else if (typeof bp?.category === 'string') {
              category = bp.category;
            }

            // website (normaliza string/array/objeto)
            let website = null;
            const ws = bp?.websites ?? bp?.website;
            if (Array.isArray(ws)) {
              website = ws.map(v => {
                if (typeof v === 'string') return v.trim();
                if (v && typeof v === 'object') return (v.url || v.link || v.value || '').toString().trim();
                return '';
              }).filter(Boolean).join(', ');
            } else if (typeof ws === 'object' && ws) {
              website = (ws.url || ws.link || ws.value || '').toString().trim() || null;
            } else if (typeof ws === 'string') {
              website = ws.trim();
            }
            if (typeof website === 'string' && website.includes(',')) {
              website = Array.from(new Set(website.split(',').map(s => s.trim()).filter(Boolean))).join(', ');
            }

            // email (normaliza string/array/objeto)
            let email = null;
            const em = bp?.email ?? bp?.emails;
            if (Array.isArray(em)) {
              email = em.map(v => (typeof v === 'string'
                ? v.trim()
                : (v && typeof v === 'object' && typeof v.email === 'string')
                  ? v.email.trim()
                  : ''))
                .filter(Boolean)
                .join(', ');
            } else if (typeof em === 'object' && em) {
              email = (em.email || em.value || '').toString().trim() || null;
            } else if (typeof em === 'string') {
              email = em.trim();
            }

            // >>> NOVOS CAMPOS PARA O C# PREENCHER BUSINESS NAME COM QUALIDADE
            const verifiedName = bp?.verifiedName?.name || null;
            const title        = bp?.title || null;

            out.businessCategory = category || null;
            out.businessWebsite  = website  || null;
            out.businessEmail    = email    || null;
            // enviamos também estes dois para o JSON (fica disponível no GetBusinessProfile)
            out.verifiedName     = verifiedName;
            out.businessName     = out.businessName || verifiedName || title || null;
          }
        } catch {}
      }

      if (showConsole) { try { console.table([out]); } catch {} }
      return out;
    } catch (e) {
      return { ...base, error: String(e && (e.message||e)), source:'exception' };
    }
  };

  g.__wppCheckNumberJSON = async (num, showConsole = false, opts = {}) => {
    try {
      const out = await g.__wppCheckNumber(num, showConsole, opts);
      return JSON.stringify(out);
    } catch (e) {
      return JSON.stringify({
        input: String(num||''),
        jid: null, exists:false, canReceive:null, isBusiness:null, code:null,
        profileStatus:null, displayName:null, pushname:null, verifiedName:null,
        notifyName:null, businessName:null, source:'__wppCheckNumber', error:String(e && (e.message||e))
      });
    }
  };

  // --------- business profile isolado (para seu GetBusinessProfile) ----------
  g.__wppGetBusinessProfileJSON = async (jidOrNumber, showConsole = false) => {
    const jid = (function toJid(n){
      n = String(n||'').trim();
      if (/@(c|g)\.us$/i.test(n)) return n.toLowerCase();
      const d = n.replace(/\D+/g,'');
      return (d || n).toLowerCase() + '@c.us';
    })(jidOrNumber);
  
    const base = {
      input: String(jidOrNumber||''),
      jid,
      category:null,
      description:null,
      email:null,
      website:null,
      verifiedName:null,   // << NOVO
      title:null,          // << NOVO
      error:null,
      source:'businessProfile'
    };
  
    try{
      const fn = window.WPP?.contact?.getBusinessProfile || window.WPP?.business?.getBusinessProfile;
      if (!fn) return JSON.stringify({ ...base, error:'getBusinessProfile não disponível' });
  
      const bp = await fn(jid);
  
      // categoria (string única)
      let category = null;
      if (Array.isArray(bp?.categories) && bp.categories.length) {
        category = bp.categories
          .map(c => c?.localized_display_name || c?.name || c?.id)
          .filter(Boolean)
          .join(' / ');
      } else if (typeof bp?.category === 'string') {
        category = bp.category;
      }
  
      // website (normaliza string/array/obj)
      let website = null;
      const ws = bp?.websites ?? bp?.website;
      if (Array.isArray(ws)) {
        website = ws.map(v => {
          if (typeof v === 'string') return v.trim();
          if (v && typeof v === 'object') return (v.url || v.link || v.value || '').toString().trim();
          return '';
        }).filter(Boolean).join(', ');
      } else if (typeof ws === 'object' && ws) {
        website = (ws.url || ws.link || ws.value || '').toString().trim() || null;
      } else if (typeof ws === 'string') {
        website = ws.trim();
      }
      if (typeof website === 'string' && website.includes(',')) {
        website = Array.from(new Set(website.split(',').map(s => s.trim()).filter(Boolean))).join(', ');
      }
  
      // email (normaliza string/array/obj)
      let email = null;
      const em = bp?.email ?? bp?.emails;
      if (Array.isArray(em)) {
        email = em.map(v => (typeof v === 'string'
          ? v.trim()
          : (v && typeof v === 'object' && typeof v.email === 'string')
            ? v.email.trim()
            : ''))
          .filter(Boolean)
          .join(', ');
      } else if (typeof em === 'object' && em) {
        email = (em.email || em.value || '').toString().trim() || null;
      } else if (typeof em === 'string') {
        email = em.trim();
      }
  
      const out = {
        ...base,
        category: category || null,
        description: bp?.description || null,
        email: email || null,
        website: website || null,
        verifiedName: bp?.verifiedName?.name || null, // << NOVO
        title: bp?.title || null                      // << NOVO
      };
  
      if (showConsole) console.log('[biz]', out);
      return JSON.stringify(out);
    }catch(e){
      return JSON.stringify({ ...base, error:String(e && (e.message||e)) });
    }
  };
  
  // idempotente
  try {
    if (!g.top.__wppCheckNumberJSON) g.top.__wppCheckNumberJSON = g.__wppCheckNumberJSON;
    if (!g.top.__wppCheckNumber)     g.top.__wppCheckNumber     = g.__wppCheckNumber;
    if (!g.top.__wppGetBusinessProfileJSON) g.top.__wppGetBusinessProfileJSON = g.__wppGetBusinessProfileJSON;
  } catch {}
})();
