// HELLO — probe leve (não depende das suas helpers)
(function () {
  window.__wpp_helper_version = '1.0.0';
  window.__wppHello = () => {
    const fns = [
      '__wppGetGroupsShort',
      '__wppGetGroupsWithRoles',
      '__wppGetGroupParticipants',
      '__wppSendTextWithMentions',
      '__wppCanISendToGroup',
      '__wppOpen',
      '__wppSendImage',
      '__wppSendAudioUnified'
    ];
    const hasWPP = !!(window.WPP && typeof WPP.chat?.list === 'function');
    const map = {};
    for (const n of fns) map[n] = (typeof window[n] === 'function');
    return {
      ok: hasWPP && fns.every(n => map[n]),
      hasWPP,
      version: window.__wpp_helper_version,
      fns: map
    };
  };
})();
