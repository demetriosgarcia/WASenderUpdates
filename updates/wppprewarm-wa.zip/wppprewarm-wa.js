// PREWARM — aquece caches e espera conexão ficar pronta
(function () {
  window.__wppPrewarm = async (opts = {}) => {
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const timeoutMs = opts.timeoutMs ?? 8000;
    const t0 = Date.now();

    // 1) Espera WPP/Store básicos
    while (!(window.WPP && (WPP.chat || WPP.contact) && (WPP.whatsapp || window.Store))) {
      if (Date.now() - t0 > timeoutMs) throw new Error('WPP/Store não carregou');
      await sleep(120);
    }
    
    // 2) Espera conexão (CONNECTED/OPEN)
    for (;;) {
      let st = null;
      try {
        st = (WPP.conn?.getState && await WPP.conn.getState()) || Store.Conn?.state;
      } catch {}
      if (st === 'CONNECTED' || st === 'OPEN') break;
      if (Date.now() - t0 > timeoutMs) throw new Error('WhatsApp não conectou');
      await sleep(200);
    }

    // 3) Hidrata caches (não falha se der erro)
    try { await WPP.chat.list(); } catch {}
    try { await WPP.contact?.list?.(); } catch {}
    try {
      const chats = await (WPP.chat.list().catch(() => []));
      const gids = (chats || [])
        .filter(c => c?.id?.server === 'g.us' || c?.isGroup)
        .slice(0, 5)
        .map(c => c?.id?._serialized || c?.id);
      await Promise.allSettled(gids.map(g => WPP.group.getGroupMetadata(g)));
    } catch {}
    try { await WPP.profile?.getMyProfile?.(); } catch {}

    return true;
  };
})();

// HELLO — probe leve (não depende das suas helpers)
(function () {
  window.__wpp_helper_version = '1.0.0';
  window.__wppHello = () => {
    const fns = [
      '__wppGetGroupsShort',
      '__wppGetGroupsWithRoles',
      '__wppGetGroupParticipants',
      '__wppSendTextWithMentions',
      '__wppCanISendToGroup',
      '__wppOpen',
      '__wppSendImage',
      '__wppSendAudioUnified'
    ];
    const hasWPP = !!(window.WPP && typeof WPP.chat?.list === 'function');
    const map = {};
    for (const n of fns) map[n] = (typeof window[n] === 'function');
    return {
      ok: hasWPP && fns.every(n => map[n]),
      hasWPP,
      version: window.__wpp_helper_version,
      fns: map
    };
  };
})();
